%ENES GÖK 2444628
clear
clc
total = 0;
iterations = 0;
k = 1;
error = 10^-5;
while error < abs(sqrt(total*6) - pi)
    iterations = iterations + 1;
    t = 1/k^2;
    total = total + t;
    k = k+1;
end
disp(iterations)


total = 1;
iterations = 0;
error = 10^-5;
r1 = 0;
while error < abs((2/total)-pi)
    iterations = iterations + 1;
    r1 = sqrt(2+r1);
    total = total*(r1/2);
end
disp(iterations)

%Vieta's formula approach so faster than euler's formula