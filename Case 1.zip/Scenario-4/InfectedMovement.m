function [i_row,i_col] = InfectedMovement(i_row,i_col,N)   
        if i_col == 1 && i_row == 1 %upper left corner
            if rand < 0.33
                i_col = i_col + 1; %to the right                
            elseif rand < 0.66
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_col == N && i_row == 1 %upper right corner
            if rand < 0.33
                i_row = i_row + 1; %to the down
            elseif rand < 0.66
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end
        elseif i_col == N && i_row == N %bottom right corner
            if rand < 0.33
                i_col = i_col - 1; %to the left
            elseif rand < 0.66
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            else
                i_row = i_row - 1; %to the up
            end
        elseif i_col == 1 && i_row == N %bottom left corner
            if rand < 0.33
                i_row = i_row - 1; %to the up
            elseif rand < 0.66
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            else
                i_col = i_col + 1; %to the right
            end
        elseif i_col == 1 && i_row ~= 1 && i_row ~= N %left edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_row == 1 && i_col ~= 1 && i_col ~= N %upper edge
            if rand < 0.2
                i_row = i_row + 1; %to the down
            elseif rand < 0.4
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end
        elseif i_col == N && i_row ~= 1 && i_row ~= N %right edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            elseif rand < 0.6
                i_col = i_col - 1; %to the left
            elseif rand < 0.8
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_row == N && i_col ~= 1 && i_col ~= N %bottom edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end    
        else    
            if rand < 0.25
                if rand < 0.5
                    i_col = i_col - 1; %to the left
                elseif rand > 0.5
                    i_row = i_row - 1; %to the left and to the up
                    i_col = i_col - 1;
                end
            elseif rand < 0.5
                if rand < 0.5
                    i_row = i_row + 1; %to the down
                elseif rand > 0.5
                    i_row = i_row + 1; %to the left and to the down
                    i_col = i_col - 1;
                end
            elseif rand < 0.75
                if rand < 0.5
                    i_col = i_col + 1; %to the right
                elseif rand > 0.5
                    i_row = i_row + 1; %to the right and to the down
                    i_col = i_col + 1;
                end 
            else
                if rand < 0.5    
                    i_row = i_row - 1; %to the up
                elseif rand > 0.5
                    i_row = i_row - 1; %to the right and to the up
                    i_col = i_col + 1;
                end
            end
        end
        