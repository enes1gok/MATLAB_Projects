function [row,col] = HealthyMovement(row,col,N)

    if col == 1 && row == 1 %upper left corner
        if rand < 0.33
            col = col + 1; %to the right
        elseif rand < 0.66
            row = row + 1; %to the right and to the down
            col = col + 1;
        else
            row = row + 1; %to the down
        end
    elseif col == N && row == 1 %upper right corner
        if rand < 0.33
            row = row + 1; %to the down
        elseif rand < 0.66
            row = row + 1; %to the left and to the down
            col = col - 1;
        else
            col = col - 1; %to the left
        end
    elseif col == N && row == N %bottom right corner
        if rand < 0.33
            col = col - 1; %to the left
        elseif rand < 0.66
            row = row - 1; %to the left and to the up
            col = col - 1;
        else
            row = row - 1; %to the up
        end
    elseif col == 1 && row == N %bottom left corner
        if rand < 0.33
            row = row - 1; %to the up
        elseif rand < 0.66
            row = row - 1; %to the right and to the up
            col = col + 1;
        else
            col = col + 1; %to the right
        end
    elseif col == 1 && row ~= 1 && row ~= N %left edge
        if rand < 0.2
            row = row - 1; %to the up
        elseif rand < 0.4
            row = row - 1; %to the right and to the up
            col = col + 1;
        elseif rand < 0.6
            col = col + 1; %to the right
        elseif rand < 0.8
            row = row + 1; %to the right and to the down
            col = col + 1;
        else
            row = row + 1; %to the down
        end
    elseif row == 1 && col ~= 1 && col ~= N %upper edge
        if rand < 0.2
            row = row + 1; %to the down
        elseif rand < 0.4
            row = row + 1; %to the right and to the down
            col = col + 1;
        elseif rand < 0.6
            col = col + 1; %to the right
        elseif rand < 0.8
            row = row + 1; %to the left and to the down
            col = col - 1;
        else
            col = col - 1; %to the left
        end
    elseif col == N && row ~= 1 && row ~= N %right edge
        if rand < 0.2
            row = row - 1; %to the up
        elseif rand < 0.4
            row = row - 1; %to the left and to the up
            col = col - 1;
        elseif rand < 0.6
            col = col - 1; %to the left
        elseif rand < 0.8
            row = row + 1; %to the left and to the down
            col = col - 1;
        else
            row = row + 1; %to the down
        end
    elseif row == N && col ~= 1 && col ~= N %bottom edge
        if rand < 0.2
            row = row - 1; %to the up
        elseif rand < 0.4
            row = row - 1; %to the right and to the up
            col = col + 1;
        elseif rand < 0.6
            col = col + 1; %to the right
        elseif rand < 0.8
            row = row - 1; %to the left and to the up
            col = col - 1;
        else
            col = col - 1; %to the left
        end    
    else    
        if rand < 0.25
            if rand < 0.5
                col = col - 1; %to the left
            elseif rand > 0.5
                row = row - 1; %to the left and to the up
                col = col - 1;
            end
        elseif rand < 0.5
            if rand < 0.5
                row = row + 1; %to the down
            elseif rand > 0.5
                row = row + 1; %to the left and to the down
                col = col - 1;
            end
        elseif rand < 0.75
            if rand < 0.5
                col = col + 1; %to the right
            elseif rand > 0.5
                row = row + 1; %to the right and to the down
                col = col + 1;
            end 
        else
            if rand < 0.5    
                row = row - 1; %to the up
            elseif rand > 0.5
                row = row - 1; %to the right and to the up
                col = col + 1;
            end
        end
    end   
end
