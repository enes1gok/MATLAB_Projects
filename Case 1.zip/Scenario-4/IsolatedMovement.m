function [i_row,i_col] = IsolatedMovement(i_row,i_col,row_bound,col_bound,N)
if row_bound == 1 && col_bound == 1 % upper left corner
    c = rand();
    if c < 0.33 % to the down
        i_row = i_row + 1;
    elseif c < 0.66 % to the right
        i_col = i_col + 1;
    else % to the right and down
        i_col = i_col + 1;
        i_row = i_row + 1;
    end
elseif row_bound == N && col_bound == 1 % lower left corner
    c = rand();
    if c < 0.33 % to the up
        i_row = i_row - 1;
    elseif c < 0.66 % to the right
        i_col = i_col + 1;
    else % to the right and up
        i_col = i_col + 1;
        i_row = i_row - 1;
    end
elseif row_bound == N && col_bound == N % lower right corner
    c = rand();
    if c < 0.33 % to the up
        i_row = i_row - 1;
    elseif c < 0.66 % to the left
        i_col = i_col - 1;
    else % to the left and up
        i_col = i_col - 1;
        i_row = i_row - 1;
    end
elseif row_bound == 1 && col_bound == N % upper right corner
    c = rand();
    if c < 0.33 % to the down
        i_row = i_row + 1;
    elseif c < 0.66 % to the left
        i_col = i_col - 1;
    else % to the left and down
        i_col = i_col - 1;
        i_row = i_row + 1;
    end

elseif row_bound == 1 && (col_bound ~= 1 && col_bound ~= N) % up edge
        c = rand();
        if c < 0.2 % to the left
            i_col = i_col - 1;
        elseif c < 0.4 % to the down
            i_row = i_row + 1;
        elseif c < 0.6 % to the right
            i_col = i_col + 1;
        elseif c < 0.8 % to the left and down
            i_col = i_col - 1;
            i_row = i_row + 1;
        else % to the right and down
            i_col = i_col + 1;
            i_row = i_row + 1;
        end
elseif row_bound == N && (col_bound ~= 1 && col_bound ~= N) % bottom edge
        c = rand();
        if c < 0.2 % to the left
            i_col = i_col - 1;
        elseif c < 0.4 % to the up
            i_row = i_row - 1;
        elseif c < 0.6 % to the right
            i_col = i_col + 1;
        elseif c < 0.8 % to the left and up
            i_col = i_col - 1;
            i_row = i_row - 1;
        else % to the right and up
            i_col = i_col + 1;
            i_row = i_row - 1;
        end
elseif col_bound == N && (row_bound ~= 1 && row_bound ~= N) % right edge
        c = rand();
        if c < 0.2 % to the left
            i_col = i_col - 1;
        elseif c < 0.4 % to the up
            i_row = i_row - 1;
        elseif c < 0.6 % to the down
            i_row = i_row + 1;
        elseif c < 0.8 % to the left and up
            i_col = i_col - 1;
            i_row = i_row - 1;
        else % to the left and down
            i_col = i_col - 1;
            i_row = i_row + 1;
        end      
elseif col_bound == 1 && (row_bound ~= 1 && row_bound ~= N) % left edge
        c = rand();
        if c < 0.2 % to the right
            i_col = i_col + 1;
        elseif c < 0.4 % to the up
            i_row = i_row - 1;
        elseif c < 0.6 % to the down
            i_row = i_row + 1;
        elseif c < 0.8 % to the right and up
            i_col = i_col + 1;
            i_row = i_row - 1;
        else % to the right and down
            i_col = i_col + 1;
            i_row = i_row + 1;
        end    
else
        if i_col == col_bound-1 && i_row == row_bound-1 %upper left corner
            if rand < 0.33
                i_col = i_col + 1; %to the right                
            elseif rand < 0.66
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_col == col_bound+1 && i_row == row_bound-1 %upper right corner
            if rand < 0.33
                i_row = i_row + 1; %to the down
            elseif rand < 0.66
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end
        elseif i_col == col_bound+1 && i_row == row_bound+1 %bottom right corner
            if rand < 0.33
                i_col = i_col - 1; %to the left
            elseif rand < 0.66
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            else
                i_row = i_row - 1; %to the up
            end
        elseif i_col == col_bound-1 && i_row == row_bound+1 %bottom left corner
            if rand < 0.33
                i_row = i_row - 1; %to the up
            elseif rand < 0.66
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            else
                i_col = i_col + 1; %to the right
            end
        elseif i_col == col_bound-1 && (i_row ~= row_bound-1 && i_row ~= row_bound+1) %left edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_row == row_bound-1 && (i_col ~= col_bound-1 && i_col ~= col_bound+1) %upper edge
            if rand < 0.2
                i_row = i_row + 1; %to the down
            elseif rand < 0.4
                i_row = i_row + 1; %to the right and to the down
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end
        elseif i_col == col_bound+1 && (i_row ~= row_bound-1 && i_row ~= row_bound+1) %right edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            elseif rand < 0.6
                i_col = i_col - 1; %to the left
            elseif rand < 0.8
                i_row = i_row + 1; %to the left and to the down
                i_col = i_col - 1;
            else
                i_row = i_row + 1; %to the down
            end
        elseif i_row == row_bound+1 && (i_col ~= col_bound-1 && i_col ~= col_bound+1) %bottom edge
            if rand < 0.2
                i_row = i_row - 1; %to the up
            elseif rand < 0.4
                i_row = i_row - 1; %to the right and to the up
                i_col = i_col + 1;
            elseif rand < 0.6
                i_col = i_col + 1; %to the right
            elseif rand < 0.8
                i_row = i_row - 1; %to the left and to the up
                i_col = i_col - 1;
            else
                i_col = i_col - 1; %to the left
            end    
        else    
            if rand < 0.25
                if rand < 0.5
                    i_col = i_col - 1; %to the left
                elseif rand > 0.5
                    i_row = i_row - 1; %to the left and to the up
                    i_col = i_col - 1;
                end
            elseif rand < 0.5
                if rand < 0.5
                    i_row = i_row + 1; %to the down
                elseif rand > 0.5
                    i_row = i_row + 1; %to the left and to the down
                    i_col = i_col - 1;
                end
            elseif rand < 0.75
                if rand < 0.5
                    i_col = i_col + 1; %to the right
                elseif rand > 0.5
                    i_row = i_row + 1; %to the right and to the down
                    i_col = i_col + 1;
                end 
            else
                if rand < 0.5    
                    i_row = i_row - 1; %to the up
                elseif rand > 0.5
                    i_row = i_row - 1; %to the right and to the up
                    i_col = i_col + 1;
                end
            end
        end
end