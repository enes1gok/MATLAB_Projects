%ENES GÖK 2444628
classdef RockPaperScissors < handle
    properties
        moveOfPlayer
        moveOfComputer
    end
    methods
        function obj = RockPaperScissors(varargin)
            if nargin > 0
                obj.moveOfPlayer = varargin{1};
                obj.moveOfComputer = varargin{2};
                obj.SetMoveP(varargin{3});
            end
        end

        function SetMoveP(self,m)
            self.moveOfPlayer = m; 
        end
        function PrintMoveP(self)
                if self.moveOfPlayer == 0
                    fprintf("You played rock!\n")
                elseif self.moveOfPlayer == 1
                    fprintf("You played paper!\n")
                elseif self.moveOfComputer == 2
                    fprintf("You played scissors!\n")
                end
        end
        function PlayC(self) 
            self.moveOfComputer = floor(2*rand);

        end
        function PrintMoveC(self)
                if self.moveOfComputer == 0
                    fprintf("Computer played rock!\n")
                elseif self.moveOfComputer == 1
                    fprintf("Computer played paper!\n")
                elseif self.moveOfComputer == 2
                    fprintf("Computer played scissors!\n")
                end
        end
        function [pw, cw]=Win(self)
            if self.moveOfComputer == 2
                if self.moveOfPlayer == 0
                    pw = 1;
                    cw = 0;
                elseif self.moveOfPlayer == 1
                    cw = 1;
                    pw = 0;
                else
                    pw = 0;
                    cw = 0;
                end
            elseif self.moveOfComputer == 1
                if self.moveOfPlayer == 0
                    cw = 1;
                    pw = 0;
                elseif self.moveOfPlayer == 1
                    cw = 0;
                    pw = 0;
                else
                    pw = 1;
                    cw = 0;
                end
            else
                if self.moveOfPlayer == 0
                    pw = 0;
                    cw = 0;
                elseif self.moveOfPlayer == 1
                    cw = 0;
                    pw = 1;
                else
                    pw = 0;
                    cw = 1;
                end
            end
        end
    end
end