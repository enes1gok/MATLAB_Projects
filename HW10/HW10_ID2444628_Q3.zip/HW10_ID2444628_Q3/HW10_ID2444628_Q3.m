%ENES GÖK 2444628
n_turns = input("Enter the number of turns you want to play: ");
winplayer = 0;
wincom = 0;
for i = 1:n_turns
    game = RockPaperScissors();
    fprintf("-----------------\n")
    fprintf("Turn %d\n",i)
    whichIs = input("Enter your move (0:Rock, 1:Paper, 2:Scissors): ");
    game.SetMoveP(whichIs)
    game.PrintMoveP
    game.PlayC
    game.PrintMoveC
    [x,y] = game.Win ;
    if x == 1 && y == 0
        winplayer = winplayer + 1;
        fprintf("You win in this turn!\n")
    elseif x == 0 && y == 1
        wincom = wincom + 1;
        fprintf("You lose in this turn!\n")
    elseif x == 0 && y == 0
        fprintf("Draw in this turn!\n")
    end
end
fprintf("-----------------\n")
if winplayer > wincom
    fprintf("Congratulations, you win the game :)\n")
elseif wincom > winplayer
    fprintf("You lose:(\n")
else
    fprintf("Draw!\n")
end