%rectangle("Position",[self.xcoordinate,self.ycoordinate,self.sideLength,self.sideLength],"Curvature",[self.curx,self.cury]);
%rectangle("Position",[self.xcoordinate,self.ycoordinate,self.width,self.height],"Curvature",[self.curx,self.cury]);
nargin = 1;

if 1 == isa("Hello, world","char")
    disp("yes")
end