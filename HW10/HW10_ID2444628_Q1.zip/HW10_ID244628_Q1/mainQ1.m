clear all
clc
close all
d=Disk(9,5,0); %radius, x coordinate, and y coordinate
d.PrintArea;
d.PrintPerimeter;
e=Square(13,5,0); %sideLength, x coordinate, and y coordinate
e.PrintArea;
e.PrintPerimeter;
f=Rectangle(5,10,5,0); %width, height, x coordinate, and y coordinate
f.PrintArea;
f.PrintPerimeter;
d.DrawShape;
hold on
e.DrawShape;
hold on
f.DrawShape;
