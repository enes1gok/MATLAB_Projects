classdef Disk < Shape
    properties
        radius
    end
    methods
        function disk = Disk(radius,xcoordinate,ycoordinate)
            disk = disk@Shape(xcoordinate,ycoordinate);
            disk.radius = radius;
        end

        function area = PrintArea(self)
            area = pi*self.radius^2;
            fprintf("Area of the circle is %.3f\n",area)

        end
        function perimeter = PrintPerimeter(self)
            perimeter = 2*pi*self.radius;
            fprintf("Perimeter of the circle is %.3f\n",perimeter)

        end
        function DrawShape(self)
            DrawShape@Shape(self.xcoordinate,self.ycoordinate,self.radius*2,self.radius*2,1,1);
        end        
    end
end