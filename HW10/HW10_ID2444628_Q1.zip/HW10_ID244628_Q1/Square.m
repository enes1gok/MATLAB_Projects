classdef Square < Shape
    properties
        sideLength
    end
    methods
        function square = Square(sideLength,xcoordinate,ycoordinate)
            square = square@Shape(xcoordinate,ycoordinate);
            square.sideLength = sideLength;
            square.curx = 0;
            square.cury = 0;
        end
        function area = PrintArea(self)
            area = self.sideLength^2;
            fprintf("Area of the square is %.3f\n",area)
        end
        function perimeter = PrintPerimeter(self)
            perimeter = 4*self.sideLength;
            fprintf("Perimeter of the square is %.3f\n",perimeter)            
        end
        function y = DrawShape(self)
            y = DrawShape@Shape(self.xcoordinate,self.ycoordinate,self.sideLength,self.sideLength,0,0);
        end        
    end
end