classdef Rectangle < Shape
    properties
        height
        width
    end
    methods
        function rectangle = Rectangle(width,height,xcoordinate,ycoordinate)
            rectangle = rectangle@Shape(xcoordinate,ycoordinate);
            rectangle.width = width;
            rectangle.height = height;
        end

        function area = PrintArea(self)
            area = self.width*self.height;
            fprintf("Area of the rectangle is %.3f\n",area)
        end
        function perimeter = PrintPerimeter(self)
            perimeter = 2*self.width+2*self.height;
            fprintf("Perimeter of the rectangle is %.3f\n",perimeter)            
        end
        function y = DrawShape(self)
            y = DrawShape@Shape(self.xcoordinate,self.ycoordinate,self.width,self.height,0,0);
        end        
    end
end