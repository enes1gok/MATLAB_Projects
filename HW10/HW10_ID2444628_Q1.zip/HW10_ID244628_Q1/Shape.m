classdef Shape < handle
    
    properties
        area
        perimeter
        xcoordinate
        ycoordinate
        incx
        incy
        curx
        cury
    end

    methods
        function shape = Shape(area,perimeter)
            shape.area = area;
            shape.perimeter = perimeter;
        end
        function printArea = PrintArea(self)
            printArea = self.area;
        end
        function printPerimeter = PrintPerimeter(self)
            printPerimeter = self.perimeter;
        end
        function DrawShape(self,xcoordinate,ycoordinate,incx,incy,curx,cury)
            self.xcoordinate = xcoordinate;
            self.ycoordinate = ycoordinate;
            self.incx = incx;
            self.incy = incy;
            self.curx = curx;
            self.cury = cury;
            rectangle("Position",[xcoordinate,ycoordinate,incx,incy],"Curvature",[curx,cury])
        end    
    end
end