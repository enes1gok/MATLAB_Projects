classdef Student < Wizard
    properties
        grade
        year
    end

    methods
        function student = Student(varargin)
            student@Wizard(varargin)
            if nargin == 8
                if 1 == isa(varargin{1},"char")
                    student.name = varargin{1};
                end
                if 1 == isa(varargin{2},"char")
                    student.surname = varargin{2};
                end
                if 1 == isa(varargin{3},"double")
                    student.birthYear = varargin{3};
                end
                if 1 == isa(varargin{4},"char")
                    student.city = varargin{4};
                end
                if 1 == isa(varargin{5},"char")
                    student.wandType = varargin{5};
                end
                if 1 == isa(varargin{6},"char")
                    student.houseInHogwarts = varargin{6};
                end
           
                if 1 == isa(varargin{7},"double")
                    student.grade = varargin{7};
                end
                if 1 == isa(varargin{8},"double")
                    student.year = varargin{8};
                end
            end
        end

        function disp(self)
            fprintf("Name of the student is %s %s.\n",self.name,self.surname)
            fprintf("%s %s is a student in %s and in year %d.\n",self.name,self.surname,self.houseInHogwarts,self.year)
        end
        function showStudentInfo(self)
            fprintf("S/he has %d out of 100.\n",self.grade)
        end
    end
end