clear all
clc
p=Person('Harry','Potter',1980,'Ankara');
m=Muggle('Hermione','Granger',1979,'Cankiri');
w=Wizard('Bellatrix','Lestrange',1951,'London','Dragon heartstring','Slytherin');
pr=Professor('Albus','Dumbledore',1960,'Konya','Murver','Gryffindor ','Transfiguration','Professor');
s=Student('Neville','Longbottom',1980,'Ankara','Unicorn hair','Gryffindor',98,2);

p.disp();
m.disp();
w.disp();
pr.showAcademicInfo();
pr.grade();
s.disp();
s.showStudentInfo();
