classdef Professor < Wizard
    properties
        courseTaught
        title
    end

    methods
        function professor = Professor(varargin)
            professor@Wizard(varargin);
            if nargin == 8
                if 1 == isa(varargin{1},"char")
                    professor.name = varargin{1};
                end
                if 1 == isa(varargin{2},"char")
                    professor.surname = varargin{2};
                end
                if 1 == isa(varargin{3},"double")
                    professor.birthYear = varargin{3};
                end
                if 1 == isa(varargin{4},"char")
                    professor.city = varargin{4};
                end
                if 1 == isa(varargin{5},"char")
                    professor.wandType = varargin{5};
                end
                if 1 == isa(varargin{6},"char")
                    professor.houseInHogwarts = varargin{6};
                end
                if 1 == isa(varargin{7},"char")
                    professor.courseTaught = varargin{7};
                end
                if 1 == isa(varargin{8},"char")
                    professor.title = varargin{8};
                end
            end
        end

        function disp(self)
            fprintf("Midterm of %s is graded by %s %s.\n",self.courseTaught,self.name,self.surname)
        end
        function showAcademicInfo(self)
            fprintf("%s %s %s teaches %s.\n",self.title,self.name,self.surname,self.courseTaught)
        end
        function grade(self)
            fprintf("Midterm of Transfiguration is graded by %s %s.\n",self.name,self.surname)
        end
    end
end