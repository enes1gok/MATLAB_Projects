classdef Wizard < Person
    properties
        wandType
        houseInHogwarts
    end

    methods
        function wizard = Wizard(varargin)
            wizard@Person(varargin);
            if nargin == 6
                if 1 == isa(varargin{1},"char")
                    wizard.name = varargin{1};
                end
                if 1 == isa(varargin{2},"char")
                    wizard.surname = varargin{2};
                end
                if 1 == isa(varargin{3},"double")
                    wizard.birthYear = varargin{3};
                end
                if 1 == isa(varargin{4},"char")
                    wizard.city = varargin{4};
                end
                if 1 == isa(varargin{5},"char")
                    wizard.wandType = varargin{5};
                end
                if 1 == isa(varargin{6},"char")
                    wizard.houseInHogwarts = varargin{6};
                end
            end
        end

        function disp(self)
            fprintf("%s %s is a wizard in %s house and has the %s wand.\n",self.name,self.surname,self.wandType,self.houseInHogwarts)
        end
    end
end