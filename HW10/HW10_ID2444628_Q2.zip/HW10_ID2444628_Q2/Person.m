classdef Person < handle
    properties
        name
        surname
        birthYear
        city
    end

    methods
        function person = Person(varargin)
            if nargin == 4
                if 1 == isa(varargin{1},"char")
                    person.name = varargin{1};
                end
                if 1 == isa(varargin{2},"char")
                    person.surname = varargin{2};
                end
                if 1 == isa(varargin{3},"double")
                    person.birthYear = varargin{3};
                end
                if 1 == isa(varargin{4},"char")
                    person.city = varargin{4};
                end
            end
        end

        function disp(self)
            fprintf("Name of the person is %s %s who is born in %s in %d.\n",self.name,self.surname,self.city,self.birthYear)
        end
    end
end