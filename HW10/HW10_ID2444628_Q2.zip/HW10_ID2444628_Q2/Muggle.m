classdef Muggle < Person
    methods
        function muggle = Muggle(varargin)
            muggle@Person(varargin);
            if nargin == 4
                if 1 == isa(varargin{1},"char")
                    muggle.name = varargin{1};
                end
                if 1 == isa(varargin{2},"char")
                    muggle.surname = varargin{2};
                end
                if 1 == isa(varargin{3},"double")
                    muggle.birthYear = varargin{3};
                end
                if 1 == isa(varargin{4},"char")
                    muggle.city = varargin{4};
                end
            end
        end

        function disp(self)
            fprintf("%s %s is a muggle who is born in %s and in %d.\n",self.name,self.surname,self.city,self.birthYear)
        end
    end
end