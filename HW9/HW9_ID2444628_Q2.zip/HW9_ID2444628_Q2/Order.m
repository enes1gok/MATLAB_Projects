%ENES GÖK 2444628
classdef Order < handle
    properties
        % fill in here
        itemsId
        specialOffersId
    end
    
    methods
        % Constructor
        function ord = Order(itId, soId)
            % fill in here
            ord.itemsId = itId;
            ord.specialOffersId = soId;
        end
        % %
        
        % Getters
        function itId = getItemsId(self)
            % fill in here
            itId = self.itemsId;
        end
        function soId = getSpecialOffersId(self)
            % fill in here
            soId = self.specialOffersId;
        end
        % %
        
        % Calculate bill
        function bill = calculateBill(self, m)
            % fill in here
            bill = 0;
            for i = 1:length(self.getItemsId())
                id = self.itemsId;
                for j = 1:length(m.getItems())
                    if m.items(j).getId() == id
                        bill = bill + m.items(j).getPrice();
                    end
                end
            end
            
            for i = 1:length(self.getSpecialOffersId())
                id = self.specialOffersId(i);
                for j = 1:length(m.getSpecialOffers())
                    if m.specialOffers(j).getId() == id
                        bill = bill + m.specialOffers(j).getPrice();
                    end
                end
            end

        end
        % %
        
        % Show order
        function showOrder(self, m)
            % do not change anything
            fprintf('------------------------------------------------------\n');
            fprintf('You have ordered the following:\n')
            for i = 1:length(self.getItemsId())
                id = self.itemsId(i);
                for j = 1:length(m.getItems())
                    if m.items(j).getId() == id
                        fprintf('%d- %s\n',id,m.items(j).getName());
                    end
                end
            end
            for i = 1:length(self.getSpecialOffersId())
                id = self.specialOffersId(i);
                for j = 1:length(m.getSpecialOffers())
                    if m.specialOffers(j).getId() == id
                        fprintf('SO-%d:\n', m.specialOffers(j).getId())
                        for l=1:length(m.specialOffers(j).itemsId)
                            itemId = m.specialOffers(j).itemsId(l);
                            for k=1:length(m.items)
                                if m.items(k).getId() == itemId
                                    name = m.items(k).getName();
                                end
                            end
                            fprintf('\t %d- %s \n', itemId, name);
                        end
                    end
                end
            end
        end
        % %
    end
end