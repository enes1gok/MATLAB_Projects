%ENES GÖK 2444628
classdef Item < handle
    properties
        id
        type
        name
        ingredients
        price
    end

    methods
        function item = Item(itemId,itemType,itemName,itemIngredients,itemPrice)
            item.id = itemId;
            item.type = itemType;
            item.name = itemName;
            item.ingredients = itemIngredients;
            item.price = itemPrice;
        end

        function itemId = getId(self)
            itemId = self.id;
        end

        function itemPrice = getPrice(self)
            itemPrice = self.price;
        end

        function itemType = getType(self)
            itemType = self.type;
        end

        function itemName = getName(self)
            itemName = self.name;
        end

        function itemIngredients = getIngredients(self)
            itemIngredients = self.ingredients;
        end
    end
end