%ENES GÖK 2444628
classdef SpecialOffer

    properties
        id
        itemsId
        price
        day
    end

    methods
        function specialOffer = SpecialOffer(soId,itemsId,soPrice,soDay)
            specialOffer.id = soId;
            specialOffer.itemsId = itemsId;
            specialOffer.price = soPrice;
            specialOffer.day = soDay;
        end

        function soId = getId(self)
            soId = self.id;
        end

        function soPrice = getPrice(self)
            soPrice = self.price;
        end

        function itemsId = getItemsId(self)
            itemsId = self.itemsId;
        end

        function soDay = getDay(self)
            soDay = self.day;
        end
    end
end