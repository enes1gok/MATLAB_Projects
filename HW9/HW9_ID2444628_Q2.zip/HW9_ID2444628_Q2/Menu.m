%ENES GÖK 2444628
classdef Menu < handle
    
    properties
        % fill in here
        items
        specialOffers
    end
    
    methods
        % Constructor
        function menu = Menu()
            % do not change anything
            menu.items = [];
            menu.specialOffers = [];
        end
        % %
        
        % Insert and delete operations
        function insertItem(self, item)
            % do not change anything
            self.items = [self.items item];
        end
        function deleteItem(self, itemId)
            % do not change anything
            for i=1:length(self.items)
                if self.items(i).getId() == itemId
                    self.items = [self.items(1:i-1) self.items(i+1:length(self.items))];
                    break;
                end
            end
        end
        function insertSpecialOffer(self, so)
            % fill in here
            % Hint: It looks like insertItem function
            self.specialOffers = [self.specialOffers so];
            
        end
        function deleteSpecialOffer(self, soId)
            % fill in here
            % Hint: It looks like deleteItem function
            for i=1:length(self.specialOffers)
                if self.specialOffers(i).getId() == soId
                    self.specialOffers = [self.specialOffers(1:i-1) self.specialOffers(i+1:length(self.specialOffers))];
                    break
                end
            end
        end
        % %
        
        % Getter, setters
        function its = getItems(self)
            % do not change anything
            its = self.items;
        end
        function setItems(self, its)
            % do not change anything
            self.items = its;            
        end
        function so = getSpecialOffers(self)
            % fill in here
            % Hint: It looks like getItems function
            so = self.specialOffers;
            
        end
        function setSpecialOffers(self, so)
            % fill in here
            % Hint: It looks like setItems function
            self.specialOffers = so;
                        
        end
        % %
        
        % Show menu and special offers
        function showMenu(self)
            % do not change anything
            fprintf('Starters:\n');
            for i=1:length(self.items)
                if strcmp(self.items(i).type,'starters')
                    fprintf('\t %d- %s (%s) \t %5.2f\n', self.items(i).id, self.items(i).name, self.items(i).ingredients, self.items(i).price)
                end
            end
            fprintf('------------------------------------------------------\n');
            fprintf('Main courses:\n');
            for i=1:length(self.items)
                if strcmp(self.items(i).type,'mainCourses')
                    fprintf('\t %d- %s (%s) \t %5.2f\n', self.items(i).id, self.items(i).name, self.items(i).ingredients, self.items(i).price)
                end
            end
            fprintf('------------------------------------------------------\n');
            fprintf('Snacks:\n');
            for i=1:length(self.items)
                if strcmp(self.items(i).type,'snacks')
                    fprintf('\t %d- %s (%s) \t %5.2f\n', self.items(i).id, self.items(i).name, self.items(i).ingredients, self.items(i).price)
                end
            end
            fprintf('------------------------------------------------------\n');
            fprintf('Drinks:\n');
            for i=1:length(self.items)
                if strcmp(self.items(i).type,'drinks')
                    fprintf('\t %d- %s (%s) \t %5.2f\n', self.items(i).id, self.items(i).name, self.items(i).ingredients, self.items(i).price)
                end
            end
            fprintf('------------------------------------------------------\n');
            fprintf('Desserts:\n');
            for i=1:length(self.items)
                if strcmp(self.items(i).type,'desserts')
                    fprintf('\t %d- %s (%s) \t %5.2f\n', self.items(i).id, self.items(i).name, self.items(i).ingredients, self.items(i).price)
                end
            end
            fprintf('------------------------------------------------------\n');
            
        end
        function showSpecialOffers(self)
            % do not change anything
            fprintf('------------------------------------------------------\n');
            fprintf('Special Offers of the Day:\n');
            for i=1:length(self.specialOffers)
                [~,currentday]=weekday(datetime('today'), 'long');
                if strcmp(currentday, self.specialOffers(i).getDay())
                    fprintf('\t SO-%d:\n', self.specialOffers(i).getId())
                    for j=1:length(self.specialOffers(i).itemsId)
                        itemId = self.specialOffers(i).itemsId(j);
                        for k=1:length(self.items)
                            if self.items(k).getId() == itemId
                                name = self.items(k).getName();
                            end
                        end
                        fprintf('\t \t %d- %s \n', itemId, name);
                    end
                    fprintf('\t \t Price: %.2f\n', self.specialOffers(i).getPrice());
                end
            end
            fprintf('------------------------------------------------------\n');
        end
        function showMenuAndSOs(self)
            % do not change anything
            self.showMenu();
            self.showSpecialOffers();
        end
        % %
    end
    
end
