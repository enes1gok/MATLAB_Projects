%ENES GÖK 2444628
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FOLLOWING LINES WITH COMMENTS ARE GIVEN JUST FOR YOUR INFORMATION.
%%% THEY SHOW THE MENU ITEMS AND HOW THE MENU IS CREATED.
%%% WHEN menuContents IS LOADED, THIS MENU WILL BE UPLOADED TO THE WORKSPACE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
st1 = Item(1, 'starters', 'Pot of chicken soup', 'Homemade noodles', 13.00);
st2 = Item(2, 'starters', 'Autumn salad', 'Pickled pumpkin', 13.00);
st3 = Item(3, 'starters', 'Roastbeef', 'Sauce remoulade with roasted potatoes', 19.50);
%
mc1 = Item(4, 'mainCourses', 'Viennese offal specialty', 'Dumplings', 18.00);
mc2 = Item(5, 'mainCourses', 'Brook Trout', 'Brown butter, steamed potatoes and tarragon horseradish sauce', 22.00);
mc3 = Item(6, 'mainCourses', 'Viennese veal liver', 'Potato-endive salad and tartar sauce', 22.00);
mc4 = Item(7, 'mainCourses', 'Viennese schnitzel', 'Veal', 25.00);
mc5 = Item(8, 'mainCourses', 'Goulache Vienne Style', 'Dumplings', 19.00);
%
dr1 = Item(9, 'drinks', 'Soda', 'Lemon', 3.50);
dr2 = Item(10, 'drinks', 'Organic apple juice', 'Apple', 3.50);
dr3 = Item(11, 'drinks', 'Homemade ice tea', 'Peach', 3.60);
%
sn1 = Item(12, 'snacks', 'Austrian cream cheese sandwich', 'Cream cheese with chives', 6.50);
sn2 = Item(13, 'snacks', 'Salmon tartare sandwich', 'Smoked and marinated salmon', 8.50);
sn3 = Item(14, 'snacks', 'French fries', 'Potato', 3.50);
%
de1 = Item(15, 'desserts', 'Einstein apple strudel', 'Vanilla sauce', 8.00);
de2 = Item(16, 'desserts', 'Cured cheese dumplings', 'Elderberry and plum sauce', 9.00);
de3 = Item(17, 'desserts', 'Kaiserschmarrn', 'Plum compote', 9.5);
de4 = Item(18, 'desserts', 'Sorbet', 'Lemon and strawberry', 1.5);
%
so1 = SpecialOffer(1, [1,4,9], 30.00, 'Monday');
so2 = SpecialOffer(2, [2,7,17], 42.00, 'Tuesday');
so3 = SpecialOffer(3, [7,14,18], 25.00, 'Wednesday');
so4 = SpecialOffer(4, [3,11,16], 30.00, 'Thursday');
so5 = SpecialOffer(5, [4,10,14], 20.00, 'Friday');
so6 = SpecialOffer(6, [2,9,12], 20.00, 'Saturday');
so7 = SpecialOffer(7, [1,6,15], 38.00, 'Sunday');
so8 = SpecialOffer(8, [3,8,18], 35.00, 'Thursday');
m = Menu();
%
m.insertItem([st1 st2 st3 mc1 mc2 mc3 mc4 mc5 dr1 dr2 dr3 sn1 sn2 sn3 de1 de2 de3 de4]);
%
m.insertSpecialOffer([so1 so2 so3 so4 so5 so6 so7 so8]);
%
clearvars -except m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

load menuContents

m.showMenuAndSOs();

load orderInfo

o.showOrder(m); %85

fprintf('------------------------------------------------------\n');
fprintf('------------------------------------------------------\n');
fprintf('Total bill is %.2f.\n', o.calculateBill(m));
o2 = Order([2, 5, 8], 3); 
fprintf('Total bill is %.2f.\n', o2.calculateBill(m));

