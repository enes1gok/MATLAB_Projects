classdef Fraction < handle 
% A Fraction has a numerator (num) and a denominator (denom).
% A negative fraction has a negative numerator and a positive denominator. 
% If the denominator is zero, set the numerator to +/- inf and the
% denominator to 1.
% Assume numerator and denominator are integers (except for the case of inf).
    
    properties
        num
        denom
    end
    
    methods
        function frac = Fraction(nu, de)
        % Constructor: construct a Fraction object and return its handle
            if de<0  % need to make denominator positive
                nu= -nu;
                de= -de;
            end
            if de==0  % set fraction to +/- inf
                frac.num= inf*nu;
                frac.denom= 1;
            else
                frac.num= nu;
                frac.denom= de;
            end
        end      
        function tf = isLessThan(self, other)
            if self.num/self.denom < other.num/other.denom
                tf = 1;
            else
                tf = 0;
            end
        
        end        
        function tf = isEqualTo(self, other)
            if self.num/self.denom == other.num/other.denom
                tf = 1;
            else
                tf = 0;
            end

        end
        function out = add(self, other)
            t = self.num;
            n = self.denom;
            q = other.num;
            p = other.denom;
            q = n*q; 
            t = p*t;
            out.num = t + q;
            out.denom = n*p;
            a = out.num;
            b = out.denom;
            if a > b && (a ~=0 && b ~=0)
                while true        
                    if isinf(out.num) == true
                        out.denom = out.denom;
                        out.num = out.num;
                        break
                    end
                    r = rem(a,b);
                    b = rem(b,r);
                    a = r;
                    if isinf(r) == true
                        out.num = Inf;
                        out.denom = 1;
                        break
                    elseif isinf(b) == true || b == 0
                        out.num = out.num/r;
                        out.denom = out.denom/r;
                        break                    
                    end
                    
                end
            elseif b > a && (a ~=0 && b ~=0)
                while true
                    if isinf(out.num) == true
                        out.denom = out.denom;
                        out.num = out.num;
                        break
                    end
                    r = rem(b,a);
                    a = rem(a,r);
                    b = r;
                    if isinf(r) == true
                        out.num = out.num/a;
                        out.denom = out.denom/a;
                        break
                    elseif isinf(a) == true
                        out.num = out.num/r;
                        out.denom = out.denom/r;
                        break                    
                    end
                    
                end
            elseif a == 0 && b ~= 0
                out.denom = out.denom;
                out.num = out.num;
            elseif a ~= 0 && b == 0
                out.denom = 1;
                out.num = Inf;
            end
        end
        
        function val = toDouble(self)
            val = double((self.num)/(self.denom));
        end
        function reduce(self)
            a = self.num;
            b = self.denom;
            if a > b && (a ~=0 && b ~=0)
                while true        
                    if isinf(self.num) == true
                        self.denom = self.denom;
                        self.num = self.num;
                        break
                    end
                    r = rem(a,b);
                    b = rem(b,r);
                    a = r;
                    if isinf(r) == true
                        self.num = Inf;
                        self.denom = 1;
                        break
                    elseif isinf(b) == true || b == 0
                        self.num = self.num/r;
                        self.denom = self.denom/r;
                        break                    
                    end
                    
                end
            elseif b > a && (a ~=0 && b ~=0)
                while true
                    if isinf(self.num) == true
                        self.denom = self.denom;
                        self.num = self.num;
                        break
                    end
                    r = rem(b,a);
                    a = rem(a,r);
                    b = r;
                    if isinf(r) == true
                        self.num = self.num/a;
                        self.denom = self.denom/a;
                        break
                    elseif isinf(a) == true
                        self.num = self.num/r;
                        self.denom = self.denom/r;
                        break                    
                    end
                    
                end
            elseif a == 0 && b ~= 0
                self.denom = self.denom;
                self.num = self.num;
            elseif a ~= 0 && b == 0
                self.denom = 1;
                self.num = Inf;
            end
        end  
    end %methods
    
end %classdef

