%ENES GÖK 2444628
clear
clc
mysheet1 = readcell("Fortunes.xlsx","UseExcel",true,"sheet","CoffeeFortuneRandom");
mysheet2 = readcell("Fortunes.xlsx","UseExcel",true,"sheet","CoffeeFortuneFigures");
mysheet3 = readcell("Fortunes.xlsx","UseExcel",true,"sheet","CardsFortune");
fprintf("Welcome to Falci Baci!\n")
fortune = input("Please enter the type of fortune (1:Coffee fortune, 2:Cards fortune): ");
if fortune == 1
    fprintf("You requested a coffee fortune.\n")
    
    fprintf("Please tell me the three things you see in your cup among this list:\nHorse, Horseshoe," + ...
        " Axe, Drum, Giraffe, " + ...
        "Bird, Road, Parrot, Sward, Unicorn, Tear, Evileye,\n Key, Car, Fullheart," + ...
        " Volcano, Duck, Chair, Brokenheart, Rooster, Tree, Frog,\n" + ...
        " Snake, Devil, Fish, Moon, Table, Baby, Aircraft, Kite: \n");
    figure1 = input("","s");
    figure2 = input("","s");
    figure3 = input("","s");
    
        for i = 1:height(mysheet2)
            if strcmp(figure1,mysheet2(i,1))
                disp(mysheet2(i,2))
            end
        end
        
        disp(mysheet1(ceil(height(mysheet1)*rand),1))
        
        for i = 1:height(mysheet2)
            if strcmp(figure2,mysheet2(i,1))
                disp(mysheet2(i,2))
            end
        end
        
        disp(mysheet1(ceil(height(mysheet1)*rand),1))
        
        for i = 1:height(mysheet2)
            if strcmp(figure3,mysheet2(i,1))
                disp(mysheet2(i,2))
            end
        end
elseif fortune == 2
    deck = cell(52,1);
    for i = ["Spades","Hearts","Diamonds","Clubs"]
        for n = 1:52
            if 1<=n && n<=13
                if n == 1
                    deck{n} = "Ace"+" "+i+" "+mysheet3(n,2);

                elseif n<=10
                    deck{n} = n+" "+i+" "+mysheet3(n,2);
                elseif n == 11
                    deck{n} = "Jack"+" "+i+" "+mysheet3(n,2);
                elseif n == 12
                    deck{n} = "Queen"+" "+i+" "+mysheet3(n,2);                  
                elseif n == 13
                    deck{n} = "King"+" "+i+" "+mysheet3(n,2);
                end
            elseif 14<=n && n<=26
                if n == 14
                    deck{n} = "Ace"+" "+i+" "+mysheet3(n,2);

                elseif n<=23
                    deck{n} = n+" "+i+" "+mysheet3(n,2);
                elseif n == 24
                    deck{n} = "Jack"+" "+i+" "+mysheet3(n,2);
                elseif n == 25
                    deck{n} = "Queen"+" "+i+" "+mysheet3(n,2);                  
                elseif n == 26
                    deck{n} = "King"+" "+i+" "+mysheet3(n,2);
                end
            elseif 27<=n && n<=39
                if n == 27
                    deck{n} = "Ace"+" "+i+" "+mysheet3(n,2);

                elseif n<=36
                    deck{n} = n+" "+i+" "+mysheet3(n,2);
                elseif n == 37
                    deck{n} = "Jack"+" "+i+" "+mysheet3(n,2);
                elseif n == 38
                    deck{n} = "Queen"+" "+i+" "+mysheet3(n,2);                  
                elseif n == 39
                    deck{n} = "King"+" "+i+" "+mysheet3(n,2);
                end          
            elseif 40<=n && n<=52
                if n == 40
                    deck{n} = "Ace"+" "+i+" "+mysheet3(n,2);

                elseif n<=49
                    deck{n} = n+" "+i+" "+mysheet3(n,2);
                elseif n == 50
                    deck{n} = "Jack"+" "+i+" "+mysheet3(n,2);
                elseif n == 51
                    deck{n} = "Queen"+" "+i+" "+mysheet3(n,2);                  
                elseif n == 52
                    deck{n} = "King"+" "+i+" "+mysheet3(n,2);
                end

            end
        end
    end
            
    fprintf("You requested a cards fortune.\n")
    type_card_fortune = input("Please tell me the type of cards fortune (1:Draw one card, 2:Draw three cards," + ...
        "3:Draw six cards): ");
    if type_card_fortune == 1
        fprintf("Shuffling and drawing one card for you.\n")
        card_number = randperm(52,1);
        disp(deck{card_number})
    elseif type_card_fortune == 2
        fprintf("Shuffling and drawing three cards for you.\n")
        card_number = randperm(52,3);
        fprintf("Past: %s\nPresent: %s\nFuture: %s",deck{card_number(3)},deck{card_number(2)},deck{card_number(1)})

    elseif type_card_fortune == 3
        fprintf("Shuffling and drawing six cards for you.\n")
        card_number = randperm(52,6);
        fprintf("Yourself: %s\nYour family: %s\nYour friends: %s\nWhat you expect: %s\nWhat you do not expect: %s\nThe outcome: %s\n",deck{card_number(6)},deck{card_number(5)},deck{card_number(4)},deck{card_number(3)},deck{card_number(2)},deck{card_number(1)})
    end 
end

