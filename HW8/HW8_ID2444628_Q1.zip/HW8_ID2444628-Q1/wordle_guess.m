function wordle_guess(trial, guess, colors)
x = 1;
y = 53 - (trial-1)*10;

for i = 1:5
     rectangle('Position',[x+2 y 2 6],'FaceColor',cell2mat(colors(i)))
     text('Position',[x+2.75 y+3],'string',guess(i),'FontSize',16)
     hold on
     x = x + 2;
end