% ENES GÖK 2444628
clear
clc
load Wordle.mat% MISSION: Upload words.mat 

chosen = words(ceil(height(words)*rand),ceil(width(words)*rand)); % MISSION: Randomly choose a word from the words cell

figure('Position', [400 250 700 500])
axis([0 20 0 60])
axis off

% Write your algorithm here
n=1;
thereisbutfalse = 0;
while n <=6
    guess = sprintf("Make your %1.0fst guess: ",n);
    user_guess = input(guess,'s');
    my_letters = split(user_guess,"");
    compare_letters = split(chosen,"");
    for k = 2:(length(compare_letters)-1)
        if strcmp(my_letters(k),compare_letters(k))
            my_colors(1,k) = "green";
        elseif strcmp(my_letters(k),compare_letters(k)) == false
            for m=2:(length(compare_letters)-1)
                if strcmp(my_letters(k),compare_letters(m)) && thereisbutfalse == 0
                    my_colors(1,k) = "cyan";
                    correctness = 1;
                end
            end
            if thereisbutfalse == 1
                break
            elseif thereisbutfalse == 0
                my_colors(1,k) = "red";
                
            end
        end
        thereisbutfalse = 0;
    end
    my_colors(1) = [];
    wordle_guess(n,user_guess,my_colors)
    n=n+1;
    if strcmp(user_guess,chosen)
        fprintf("Congratulations! You guessed the word in your %1.0fth guess.",n-1)
        break
    elseif strcmp(user_guess,chosen)==false && n == 7
        fprintf("You lose! Today, Wordle was %s.",chosen{1})
    end
end