a = split("enes","");
disp(a(2))