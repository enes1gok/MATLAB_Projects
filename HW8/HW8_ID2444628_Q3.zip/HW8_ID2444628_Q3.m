%ENES GÖK 2444628
clear
clc
distance = ceil(10*rand+10);
circle_1 = struct("centerx",3,"centery",3,"radius",ceil(10*rand+10));
a = 1;
while distance > 10^-20
    if a == 1 
        r = ceil(10*rand+10);
        if rand < .5
            
            if rand < .5
                %right;
                new_circle = struct("centerx",circle_1.centerx+circle_1.radius+distance+r,"centery",circle_1.centery,"radius",r);
            elseif rand > .5
                %left;
                new_circle = struct("centerx",circle_1.centerx-circle_1.radius-distance-r,"centery",circle_1.centery,"radius",r);
            end
        elseif rand > .5
            if rand < .5
                %down;
                new_circle = struct("centerx",circle_1.centerx,"centery",circle_1.centery-circle_1.radius-distance-r,"radius",r);
            elseif rand > .5
                %up;
                new_circle = struct("centerx",circle_1.centerx,"centery",circle_1.centery+circle_1.radius+distance+r,"radius",r);
            end
        end
    elseif a == 2
        new_circle.radius = ceil(10*rand+10);
        min_circle = struct("centerx",0,"centery",0,"radius",min(circle_1.radius,new_circle.radius));
        
        distance = distance / 2;
        if min_circle.radius == circle_1.radius
            min_circle = circle_1;
            if rand < .5
                if rand < .5
                    %right;
                    new_circle.centerx = min_circle.centerx+min_circle.radius+distance+new_circle.radius;   
                    new_circle.centery = min_circle.centery;
                elseif rand > .5
                    %left;
                    new_circle.centerx = min_circle.centerx-min_circle.radius-distance-new_circle.radius;
                    new_circle.centery = min_circle.centery;
                end
            elseif rand > .5
                if rand < .5
                    %down;
                    new_circle.centerx = min_circle.centerx; 
                    new_circle.centery = min_circle.centery-min_circle.radius-distance-new_circle.radius;
                elseif rand > .5
                    %up;
                    new_circle.centerx = min_circle.centerx; 
                    new_circle.centery = min_circle.centery+min_circle.radius+distance+new_circle.radius;
                end
            end
        elseif min_circle.radius == new_circle.radius
             min_circle = new_circle;
                if rand < .5
                    if rand < .5
                        %right;
                        new_circle.centerx = min_circle.centerx+min_circle.radius+distance+new_circle.radius;
                    elseif rand > .5
                        %left;
                        new_circle.centerx = min_circle.centerx-min_circle.radius-distance-new_circle.radius;
                    end
                elseif rand > .5
                    if rand < .5
                        %down;
                        new_circle.centery = min_circle.centery-min_circle.radius-distance-new_circle.radius;
                    elseif rand > .5
                        %up;
                        new_circle.centery = min_circle.centery+min_circle.radius+distance+new_circle.radius;
                    end
                end
        end
    else
        min_circle.radius = min(min_circle.radius,new_circle.radius);
        new_circle.radius = ceil(10*rand+10);
        distance = distance / 2;
        if min_circle.radius == new_circle.radius
            min_circle.centerx = new_circle.centerx;
            min_circle.centery = new_circle.centery;
                if rand < .5
                    if rand < .5
                        %right;
                        new_circle.centerx = min_circle.centerx+min_circle.radius+distance+new_circle.radius;
                    elseif rand > .5
                        %left;
                        new_circle.centerx = min_circle.centerx-min_circle.radius-distance-new_circle.radius;
                    end
                elseif rand > .5
                    if rand < .5
                        %down;
                        new_circle.centery = min_circle.centery-min_circle.radius-distance-new_circle.radius;
                    elseif rand > .5
                        %up;
                        new_circle.centery = min_circle.centery+min_circle.radius+distance+new_circle.radius;
                    end
                end
        else
            
            if rand < .5
                if rand < .5
                    %right;
                    new_circle.centerx = min_circle.centerx+min_circle.radius+distance+new_circle.radius;
                    new_circle.centery = min_circle.centery;
                elseif rand > .5
                    %left;
                    new_circle.centerx = min_circle.centerx-min_circle.radius-distance-new_circle.radius;
                    new_circle.centery = min_circle.centery;
                end
            elseif rand > .5
                if rand < .5
                    %down;
                    new_circle.centerx = min_circle.centerx; 
                    new_circle.centery = min_circle.centery-min_circle.radius-distance-new_circle.radius;
                elseif rand > .5
                    %up;
                    new_circle.centerx = min_circle.centerx; 
                    new_circle.centery = min_circle.centery+min_circle.radius+distance+new_circle.radius;
                end
            end
        end
    end
    a = a + 1;
end
euc = sqrt((circle_1.centerx - new_circle.centerx)^2+ (circle_1.centery - new_circle.centery)^2);
fprintf("Distance between disk 1 and disk %1.0f = %f",a,euc)
 
