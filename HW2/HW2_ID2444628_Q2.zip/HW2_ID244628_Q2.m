%ENES GÖK 2444628
clear
clc
length = 5.8*rand(1) - 0.4;
radian = 1.5708*rand(1);
distance = length/5;
maxdis = 0.4*sin(radian);
mindis = 0*sin(radian);
if ((0.0 <= length) && (length <= 0.4)) || ((0.6 <= length) && (length <= 1.4)) || ((1.6 <= length) && (length <= 2.4)) || ((2.6 <= length) && (length <= 3.4)) || ((3.6 <= length) && (length <= 4.4)) || ((4.6 <= length) && (length <= 5))
    if (mindis <= distance) && (distance <= maxdis)
        disp("Intersection!")
    else
        disp("No intersection!")
    end
elseif (length < 0) || (5 < length)
    disp("Pen falls down.")
else
    disp("No intersection!")

end
