%ENES GÖK 2444628
clear
clc

hits = 0;
for i = 1:1000000
    xpoint = 4*rand(1) - 2;
    ypoint = rand(1);
    if cos(1/xpoint)^2 >= ypoint
        hits = hits + 1;
    end
end
result = 4*hits/1000000;
