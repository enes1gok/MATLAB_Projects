%ENES GÖK 2444628
clear
clc

day = input("Enter the day(from 1 to 30): ");
month = input("Enter the month(from 1 to 12): ");
year = input("Enter the year: ");

specific_day = 7;
specific_month = 3;
specific_year = 2022;

if 1 == mod(day,7)
    name = "It is Monday.";
elseif 2 == mod(day,7)
    name = "It is Tuesday.";
elseif 3 == mod(day,7)
    name = "It is Wednesday.";
elseif 4 == mod(day,7)
    name = "It is Thursday.";
elseif 5 == mod(day,7)
    name = "It is Friday.";
elseif 6 == mod(day,7)
    name = "It is Saturday.";
elseif 0 == mod(day,7)
    name = "It is Sunday.";
end

if specific_day >= day
    d_day = specific_day - day;
    if specific_month >= month
        d_month = specific_month - month;
        d_year = specific_year - year;
    else
        d_month = specific_month - month + 12;
        d_year = (specific_year-1) - year;
    end
else
    d_day = 30 + specific_day - day;
    if (specific_month-1) >= month
        d_month = (specific_month-1) - month;
        d_year = (specific_year-1) - year;
    else
        d_month = (specific_month-1) - month + 12;
        d_year = (specific_year-1) - year;
         
    end

end


fprintf(name)
fprintf("The difference between 7.3.2022 and %1.0f.%1.0f.%1.0f is %1.0f year(s) %1.0f month(s) %1.0f day(s).\n",day,month,year,d_year,d_month,d_day)
