%ENES GÖK 2444628
clear
clc
trials = input("Number of trials: ");
heads3 = 0;
heads6 = 0;
heads9 = 0;
for j=1:trials
    headsnumber = 0;
    for i=1:10
        headprob = rand(1);
        if headprob > 0.5
            headsnumber = headsnumber + 1;
        end
        if headsnumber == 3 && i == 10
            heads3 = heads3 + 1;
        elseif headsnumber == 6 && i == 10
            heads6 = heads6 + 1;
        elseif headsnumber == 9 && i == 10
            heads9 = heads9 + 1;
        end
    end
end
fprintf("Number of 3 heads: %f", heads3)
fprintf("\nThe probability of 3 heads: %f", heads3/trials)
fprintf("\nNumber of 6 heads: %f", heads6)
fprintf("\nThe probability of 6 heads: %f", heads6/trials)
fprintf("\nNumber of 9 heads: %f", heads9)
fprintf("\nThe probability of 9 heads: %f", heads9/trials)

%As I increased the number of trials, I got closer to the actual probability value.
%Example; Actual value: 0.1171875 and I found 0.117520 in 100000 trials