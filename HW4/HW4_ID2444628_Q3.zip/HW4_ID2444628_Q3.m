%ENES GÖK 2444628
clear
clc
height_of_the_glass = 7.5;
height_of_a_cylinder = 0.1;
volume_of_the_glass = 0;
height_of_the_tea = 0;
amount_of_the_tea = input("Please enter the amount of tea (between 1 and 100): ");
for i = 1:1:75  
    r = 2 + (sin(height_of_a_cylinder*i+0.2)/2);
    volume_of_cylinder = pi*(r^2)*height_of_a_cylinder;
    volume_of_the_glass = volume_of_the_glass + volume_of_cylinder;
    if amount_of_the_tea <= volume_of_the_glass
        height_of_the_tea = height_of_the_tea + 0.1*(i-1);
        last_cylindir = volume_of_the_glass - height_of_the_tea;
        height_of_last_cylindir = last_cylindir*0.1/volume_of_cylinder;
        height_of_the_tea = height_of_the_tea + height_of_last_cylindir;
        break
    end
end
fprintf("Total height of the tea is %f units.",height_of_the_tea)
