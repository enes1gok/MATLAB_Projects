%ENES GÖK 2444628
clear
clc
firstx=0;
secondx=0;
thirdx=0;
fourthx=0;
a = 0;
sum = 0;
iteration = 0;
n = 1;
initialization = "first";
variable1 = "x1";variable2 = "x2";variable3 = "x3";variable4 = "x4";
while n<4
    while true 
        firstcurrentx = (12-secondx-thirdx-2*fourthx)/9;
        sum = sum + (firstcurrentx-firstx)^2;
       
        secondcurrentx = (18-2*firstx-3*thirdx+fourthx)/10;
        sum = sum + (secondcurrentx-secondx)^2;
    
        thirdcurrentx = (1-4*secondx-3*firstx-fourthx)/11;
        sum = sum + (thirdcurrentx-thirdx)^2;
    
        fourthcurrentx = 7-firstx-2*secondx+thirdx;
        sum = sum + (fourthcurrentx-fourthx)^2; 
        
        total_error = sqrt(sum);
        
        iteration = iteration + 1;
        if total_error < 10^-2 && a == 0
            fprintf("For stopping criteria 10−2:\n")
            fprintf("When it starts with the %s initialization, it takes %f iteration,\n", initialization, iteration)
            fprintf("and the result is %s = %f, %s = %f, %s = %f, %s = %f\n",variable1,firstx,variable2,secondx,variable3,thirdx,variable4,fourthx)
            a = a + 1;
        end
        if total_error < 10^-4 && a == 1
            fprintf("For stopping criteria 10−4:\n")
            fprintf("When it starts with the %s initialization, it takes %f iteration,\n", initialization, iteration)
            fprintf("and the result is %s = %f, %s = %f, %s = %f, %s = %f\n",variable1,firstx,variable2,secondx,variable3,thirdx,variable4,fourthx)
            a = a + 1;
        end
        if total_error < 10^-6 && a == 2
            fprintf("For stopping criteria 10−6:\n")
            fprintf("When it starts with the %s initialization, it takes %f iteration,\n", initialization, iteration)
            fprintf("and the result is %s = %f, %s = %f, %s = %f, %s = %f\n",variable1,firstx,variable2,secondx,variable3,thirdx,variable4,fourthx)
            a = 0;
            break
        end
        firstx = firstcurrentx;
        secondx = secondcurrentx;
        thirdx = thirdcurrentx;
        fourthx = fourthcurrentx;
        sum = 0;
    end
    n = n + 1;
    if n == 2
        initialization = "second";
        variable1 = "y1";variable2 = "y2";variable3 = "y3";variable4 = "y4";
        iteration = 0;
        
        firstx=10;
        secondx=10;
        thirdx=10;
        fourthx=10;

    elseif n == 3
        initialization = "third";
        variable1 = "z1";variable2 = "z2";variable3 = "z3";variable4 = "z4";
        iteration = 0;
        
        firstx=1;
        secondx=1;
        thirdx=1;
        fourthx=1;
    end
    
end