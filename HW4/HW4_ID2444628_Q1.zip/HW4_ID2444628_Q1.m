%ENES GÖK 2444628   
clear
clc
number_of_games = input("How many times do you wanna play?: ");
n = 0;
number_of_wins = 0;
number_of_losses = 0;

while number_of_games > n
    result = "";
    dice1 = ceil(6*rand);
    dice2 = ceil(6*rand);
    if (dice1 + dice2) == 7 || (dice1 + dice2) == 11
        number_of_wins = number_of_wins + 1;
        result = result + string(dice1 + dice2) + ": You WIN with this sequence.\n";
    elseif (dice1 + dice2) == 2 || (dice1 + dice2) == 3 || (dice1 + dice2) == 12
        number_of_losses = number_of_losses + 1;
        result = result + string(dice1 + dice2) + ": You LOSE with this sequence.\n";
    else
        a = (dice1 + dice2);
        result = result + string(dice1 + dice2) + ",";
        while true
            rerolled_dice1 = ceil(6*rand);
            rerolled_dice2 = ceil(6*rand);
            if (rerolled_dice1 + rerolled_dice2) == a
                number_of_wins = number_of_wins + 1;
                result = result + string(rerolled_dice1 + rerolled_dice2) + ": You WIN with this sequence.\n";
                break
            elseif (rerolled_dice1 + rerolled_dice2) == 7
                number_of_losses = number_of_losses + 1;
                result = result + string(rerolled_dice1 + rerolled_dice2) + ": You LOSE with this sequence.\n";
                break
            
            else
                result = result + string(rerolled_dice1 + rerolled_dice2) + ",";
            end
        end
    end
    fprintf(result)
    n = n + 1;
end
average = number_of_wins/number_of_games;

fprintf("Average = %f",average)