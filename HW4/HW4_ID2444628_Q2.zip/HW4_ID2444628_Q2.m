%ENES GÖK 2444628
clear
clc
height_of_the_glass = 7.5;
height_of_a_cylinder = 0.1;
volume_of_the_glass = 0;
volume_of_the_glass2 = 0;
volume_of_the_glass3 = 0;
volume_of_the_glass5 = 0;
for i = 1:75  
    r = 2 + (sin(height_of_a_cylinder*i+0.2)/2);
    volume_of_cylinder = pi*(r^2)*height_of_a_cylinder;
    volume_of_the_glass = volume_of_the_glass + volume_of_cylinder;
    volume_of_the_glass2 = volume_of_the_glass2 + round(volume_of_cylinder,2);
    volume_of_the_glass3 = volume_of_the_glass3 + round(volume_of_cylinder,3);
    volume_of_the_glass5 = volume_of_the_glass5 + round(volume_of_cylinder,5);
end

fprintf("Relative error in 2 decimal rounding is %f",(abs(volume_of_the_glass-volume_of_the_glass2)/volume_of_the_glass)*100)
fprintf("\nRelative error in 3 decimal rounding is %f",(abs(volume_of_the_glass-volume_of_the_glass3)/volume_of_the_glass)*100)
fprintf("\nRelative error in 5 decimal rounding is %f",(abs(volume_of_the_glass-volume_of_the_glass5)/volume_of_the_glass)*100)