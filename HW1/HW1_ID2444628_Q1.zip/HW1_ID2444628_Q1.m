%ENES GÖK 2444628
clear
clc
fprintf('Welcome to Egg Counter! Calculate the seconds required to cook an egg!')
m = input('\nWhat is the mass of the egg? (Small: 47g, Large: 67g): ');
p = 1.038;
c = 3.7;
t0 = 4;
tW = 25;
tY = 20;
newt0 = 20;
newtW = 100;
newtY = 70;
t = ((m^(2/3)*c*p^(1/3))/0.13849)*log(0.76*((t0-tW)/(tY-tW)));
newt = ((m^(2/3)*c*p^(1/3))/0.13849)*log(0.76*((newt0-newtW)/(newtY-newtW)));
fprintf('You need %f seconds to make the egg in the desired temperature in the first step.\n',t);
fprintf('You need %f seconds to make the egg in the desired temperature in the second step.\n',newt);
fprintf('You need %f seconds in total to cook the egg.',t+newt);