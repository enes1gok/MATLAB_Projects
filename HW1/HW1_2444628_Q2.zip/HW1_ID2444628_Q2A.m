%ENES GÖK 2444628
clear
clc
questionA = 6 + 33*rand


