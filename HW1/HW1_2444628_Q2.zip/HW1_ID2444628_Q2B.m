%ENES GÖK 2444628
clear
clc
questionB = floor(5 + 36*rand)