%ENES GÖK 2444628
clear
clc
n = 1;
approximation = 0;
real_area = 0.31869940426982923;
error = 10^-2;
while error < abs(real_area - approximation)
    n = n + 1;
    approximation = 0;
    lower_bound = 0.2;
    upper_bound = 2.5;
    i = 0.2;
    delta_x = (upper_bound-lower_bound)/n;
    while i < upper_bound 
        y = sin(2*i);
        nexty = sin(2*(i+delta_x));
        if y*nexty >= 0
            subarea = delta_x*((y+nexty)/2);
            approximation = approximation + subarea;
        else
            subarea = (delta_x/2)*((abs(y)/abs(y)+abs(nexty))*y+(abs(nexty)/abs(y)+abs(nexty))*nexty);
            approximation = approximation + subarea;
        end
        i = i + delta_x;
    end
    
end

fprintf("For AE = 10^−2: The required least number of subintervals: %f",n)


n = 1;
approximation = 0;
real_area = 0.31869940426982923;
error = 10^-4;
while error < abs(real_area - approximation)
    n = n + 1;
    approximation = 0;
    lower_bound = 0.2;
    upper_bound = 2.5;
    i = 0.2;
    delta_x = (upper_bound-lower_bound)/n;
    while i < upper_bound 
        y = sin(2*i);
        nexty = sin(2*(i+delta_x));
        if y*nexty >= 0
            subarea = delta_x*((y+nexty)/2);
            approximation = approximation + subarea;
        else
            subarea = (delta_x/2)*((abs(y)/abs(y)+abs(nexty))*y+(abs(nexty)/abs(y)+abs(nexty))*nexty);
            approximation = approximation + subarea;
        end
        i = i + delta_x;
    end
    
end

fprintf("\nFor AE = 10^−4: The required least number of subintervals: %f",n)



n = 1;
approximation = 0;
real_area = 0.31869940426982923;
error = 10^-6;
while error < abs(real_area - approximation)
    n = n + 1;
    approximation = 0;
    lower_bound = 0.2;
    upper_bound = 2.5;
    i = 0.2;
    delta_x = (upper_bound-lower_bound)/n;
    while i < upper_bound 
        y = sin(2*i);
        nexty = sin(2*(i+delta_x));
        if y*nexty >= 0
            subarea = delta_x*((y+nexty)/2);
            approximation = approximation + subarea;
        else
            subarea = (delta_x/2)*((abs(y)/abs(y)+abs(nexty))*y+(abs(nexty)/abs(y)+abs(nexty))*nexty);
            approximation = approximation + subarea;
        end
        i = i + delta_x;
    end
    
end

fprintf("\nFor AE = 10^−6: The required least number of subintervals: %f",n)

%The more trapezoids we divide the graph, the less error we get.

