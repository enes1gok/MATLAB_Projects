%ENES GÖK 2444628
clear
clc




n = 0;
pro = 0;
fall = 0;
while n ~= 10000
    x = 100.8*rand(1)-0.4;
    y = 5.8*rand(1)-0.4;
    theta = rand(1)*1.5708;
    length = 0.8;
    distance = length/5;
    maxdis = 0.4*sin(theta);
    mindis = 0*sin(theta);
     a = 0.4;
     b = 0.6;
     for i = 0:100
        if (x <= a) || (b <= x)
            if (mindis <= distance) && (distance <= maxdis)
                
                pro = pro + 1;
                break
            end
        end
        a = a + 1;
        b = b + 1;
    end
    
    if (x < 0) || (100 < x) || (y < 0) || (5 < y)
        fall = fall + 1;
    end
    n = n + 1; 
end
fprintf("Pen remains on the table with a probability of %f", (n-fall)/n)
fprintf("\nPen intersects with parallel lines with a probability of %f", pro/n)








