%ENES GÖK 2444628
clear
clc
sum = 0;
while sum < 1
    sum = sum + rand(1);
end
fprintf("My number is %f", sum)