%ENES GÖK 2444628 
%ALİ ÖZÇELİK 2306579
classdef Patient
    properties
        name
        surname
        priority
        day
    end
    methods
        function m = Patient(name,surname,priority,day)
            m.name = name;
            m.surname = surname;
            m.priority = priority;
            m.day = day;
        end
        function t = getPatientPriority(self)
            t = self.priority;
        end
        function setPatientPriority(self,f)
            self.priority = f;
        end
        function t = getPatientDay(self)
            t = self.day;
        end
        function setPatientDay(self,f)
            self.day = f;
        end
    end
end