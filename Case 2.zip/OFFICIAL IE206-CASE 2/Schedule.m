%ENES GÖK 2444628 
%ALİ ÖZÇELİK 2306579
classdef Schedule
    properties
        dailyPlanningHorizon
        planningDays
        numberOfRooms
        finalSchedule
    end
    methods
        function m = Schedule(dailyPlanningHorizon,planningDays,numberOfRooms,finalSchedule)
            m.dailyPlanningHorizon = dailyPlanningHorizon;
            m.planningDays = planningDays;
            m.numberOfRooms = numberOfRooms;
            m.finalSchedule = finalSchedule;
        end
        function constructSchedule(self,w,i,j,l) % in the beginning the property finalSchedule is an empty cell array, and it will be updated in this method.
            self.finalSchedule{i} = w{j,l};
        end
        function printSchedule(self)
            disp(self.finalSchedule)
        end
    end
end