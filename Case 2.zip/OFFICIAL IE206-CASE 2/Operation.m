%ENES GÖK 2444628 
%ALİ ÖZÇELİK 2306579
classdef Operation
    properties
        Id
        Patient
        availableInterval
        scheduledInterval
        duration
        operationDay
    end
    methods
        function m = Operation(Id,Patient,availableInterval,scheduledInterval,duration,operationDay)
            m.Id = Id;
            m.Patient = Patient;
            m.availableInterval = availableInterval;
            m.scheduledInterval = scheduledInterval;            
            m.duration = duration;
            m.operationDay = operationDay;
        end
        function w = setScheduledInterval(self)
            w = self.scheduledInterval;
        end
        function v = setAvailableInterval(self)
            v = self.availableInterval;
        end
    end
end