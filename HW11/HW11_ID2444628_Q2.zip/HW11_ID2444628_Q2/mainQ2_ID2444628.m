%Enes gök 2444628
clear
clc
close all
DrawTree_ID2444628(1,60,9,90,40,[0 0])
%DrawTree(level,length,numLevels,angle,dAngle,ref)

% level: the level we are at
% length: length of the Main Branch
% numLevels: total number of levels of the tree
% angle: angle between the Main Branch and x - axis
% dAngle: angle between the Main Branch and the new branch
% ref: reference point of the Main Branch
