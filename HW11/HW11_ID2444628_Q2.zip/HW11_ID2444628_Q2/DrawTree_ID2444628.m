function DrawTree_ID2444628(level,length,numLevels,angle,dAngle,ref)
plot(ref(1)-sind(abs(angle-dAngle))*length,ref(2)+(cosd(abs(angle-dAngle))*length))
DrawTree_ID2444628(level+1,length*0.7,numLevels,abs(angle-dAngle),dAngle,[ref(1)-sind(abs(angle-dAngle))*length*0.7 ref(2)+cosd(abs(angle-dAngle))*length*0.7])
end