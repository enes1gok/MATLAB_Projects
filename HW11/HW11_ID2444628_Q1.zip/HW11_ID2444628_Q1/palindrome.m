function output = palindrome(string)
    if length(string) > 1
        if string(1:2) == string(length(string)-1:length(string))
            if true == isPalindrome(string)
                output = string;
            else
                output = palindrome(string(1:length(string)-1));
            end
        else
            output = palindrome(string(1:length(string)-1));
        end
    
    end
end