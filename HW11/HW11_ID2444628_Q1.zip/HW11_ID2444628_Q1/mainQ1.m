%ENES GÖK 2444628
clear
clc
a = "enes";
a = substr(a,1);
str= input('String to be tested: \n', 's');
pal = palindrome(str);
if length(pal)==1
    fprintf('The string %s does NOT include a palindrome. \n',str);
else
    fprintf('The string %s, includes palindrome %s. \n',str, pal);
end