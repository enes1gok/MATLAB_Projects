function tf = isPalindrome(string)
    a = 0;
    if rem(length(string),2) == 0
        for i = 1:length(string)/2
            if string(i) == string(length(string)-i+1)
                a = a + 1;
            else
                tf = false;
            end
        end
        if a == length(string)/2
            tf = true;
        end
    else
        tf = false;
    end
end