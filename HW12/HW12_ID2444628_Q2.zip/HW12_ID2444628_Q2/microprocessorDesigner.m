%ENES GÖK 2444628
function microprocessorDesigner(xcoor1,ycoor1,length,width,level,color1,color2,color3)
if level == 0
    return
end
xcoor2 = xcoor1-width/2;
ycoor2 = ycoor1-length/2;

xcoor3 = xcoor1+width/2;
ycoor3 = ycoor1+length/2;

line([xcoor2 xcoor3] ,[ycoor1 ycoor1],'color',[color1,color2,color3])
line([xcoor2 xcoor2] ,[ycoor2 ycoor3],'color',[color1,color2,color3])
line([xcoor3 xcoor3] ,[ycoor2 ycoor3],'color',[color1,color2,color3])

microprocessorDesigner(xcoor2,ycoor2,length/2,width/2,level-1,color1/2,color2/2,color3/2)
microprocessorDesigner(xcoor2,ycoor2+length,length/2,width/2,level-1,color1/2,color2/2,color3/2)
microprocessorDesigner(xcoor3,ycoor3,length/2,width/2,level-1,color1/2,color2/2,color3/2)
microprocessorDesigner(xcoor3,ycoor3-length,length/2,width/2,level-1,color1/2,color2/2,color3/2)
