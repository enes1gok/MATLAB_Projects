%ENES GÖK 2444628
clear
clc
datas = readmatrix("Input_Parameters_Spr2022.xlsx");
microprocessorDesigner(datas(1,1),datas(1,2),datas(1,3),datas(1,4),datas(1,5),datas(1,6),datas(1,7),datas(1,8))
%axis equal