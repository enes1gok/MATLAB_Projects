%ENES GÖK 2444628  
clear
clc
packaging(5,'brokenTruck','floor','newTruck')