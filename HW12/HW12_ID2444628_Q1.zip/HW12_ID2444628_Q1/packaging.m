function packaging(number_of_packages,location1,location2,location3)
if number_of_packages>=1
        packaging(number_of_packages-1,location1,location2,location3);
        fprintf('Move package %d from  %s to %s\n',number_of_packages, location1, location2);

        packaging(number_of_packages-2,location1,location2,location3);
        fprintf('Move package %d from  %s to %s\n',number_of_packages, location2, location3);

        packaging(number_of_packages-3,location1,location2,location3);
end
if number_of_packages == 0
    return
end