%ENES GÖK 2444628
function output = InsertionSorting(input)
    n = length(input);
    i = 2;
    while i <= n
        j = i-1;
        while(j >= 1)
            if(input(i) < input(j)) %Swap
                temp = input(j);
                input(j) = input(i);
                input(i) = temp;
                i = j;
            end
            j=j-1;
        end
        i = i + 1;
    end
    output = input;
end