%ENES GÖK 2444628
function output = MergeSorting(input)
    n = length(input);
    if n < 2
        output = input;
        return
    end
    half_n = floor(n/2);
    first_x = MergeSorting(input(1:half_n));
    second_x = MergeSorting(input(half_n+1:n));
    a = 1;
    b = 1;
    output = [];
    n1 = length(first_x);
    n2 = length(second_x);

    while a <= n1
        if b > n2 
            output = [output first_x(a)];
            a = a+1;
            continue
        end
        if first_x(a) < second_x(b) 
            output = [output first_x(a)];
            a = a+1;
        else
            output = [output second_x(b)];
            b = b+1;
        end
    end
    c = b;
    while c <= n2
        output = [output second_x(c)];
        c = c + 1;
    end
end