%ENES GÖK 2444628
function output = QuickSorting(input)
    n = length(input);
    if n < 2
        output = input;
        return
    end
    first_x = [];
    second_x = [];
    a = 1;
    while a <= n-1
        if input(a) < input(n)
            first_x = [first_x input(a)];
        else
            second_x = [second_x input(a)];
        end
        a = a + 1;
    end
    output = [QuickSorting(first_x) input(n) QuickSorting(second_x)]; 
end