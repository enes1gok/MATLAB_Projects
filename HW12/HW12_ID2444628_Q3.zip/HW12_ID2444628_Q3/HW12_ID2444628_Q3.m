%ENES GÖK 2444628
clear
clc
x=["Naz","Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan"];
y=["Naz","Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan","Naz" , "Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Sevgi","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan"];
z=["Naz","Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan","Naz","Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Sevgi","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan","Naz","Cem","Tuna","Dilay","Ceren","Gunsu","Erdinc","Batu","Derren","Dilan","Ceyhan","Alper","Yagmurcan","Melis","Nazli","Ali","Batuhan","Derya","Tunahan","Melissa","Ceyhun","Ceyda","Yagmur","Kemal","Canan","Sevgi","Melis","Alp","Umut","Murat","Mustafa","Serhan","Serkan"];
N=length(x);
M=length(y);
L=length(z);
tic
QuickSorting(x);
list1=toc;
tic
InsertionSorting(x);
list2=toc;
tic
MergeSorting(x);
list3=toc;
figure 
hold on;
plot([0 N],[0 list1],'--','color','r')
plot([0 N],[0 list2],'--','color','g')
plot([0 N],[0 list3],'--','color','b')
xlabel('Numbers of names')
ylabel('Times')
title('RED: QuickSorting  GREEN: InsertionSorting  BLUE: MergeSorting')
grid on
