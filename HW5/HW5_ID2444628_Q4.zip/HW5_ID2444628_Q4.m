%ENES GÖK 2444628
clear
clc
N =10;
step_number = 1;
location = [0,0];
n=0;

while true
    if location(1) == N && abs(location(2)) < N
        mylimit1 = rand;
        if mylimit1 < 1/3
            location(2) = location(2) + 1; % North
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit1 > 1/3 && mylimit1 < 2/3
            location(2) = location(2) - 1; % South
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit1 < 1 && mylimit1 > 2/3
            location(1) = location(1) - 1; % West
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end
    elseif location(1) == -N && abs(location(2)) < N
        mylimit2 = rand;
        if mylimit2 < 1/3
            location(2) = location(2) + 1; % North
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit2 > 1/3 && mylimit2 < 2/3
            location(2) = location(2) - 1; % South
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit2 < 1 && mylimit2 > 2/3
            location(1) = location(1) + 1; % East
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end
    elseif location(2) == N && abs(location(1)) < N
        mylimit3 = rand;
        if mylimit3 < 1/3
            location(1) = location(1) + 1; % East
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit3 > 1/3 && mylimit3 < 2/3
            location(2) = location(2) - 1; % South
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit3 < 1 && mylimit3 > 2/3
            location(1) = location(1) - 1; % West
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end
    elseif location(2) == -N && abs(location(1)) < N
        mylimit4 = rand;
        if mylimit4 < 1/3
            location(2) = location(2) + 1; % North
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit4 > 1/3 && mylimit4 < 2/3
            location(1) = location(1) + 1; % East
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit4 < 1 && mylimit4 > 2/3
            location(1) = location(1) - 1; % West
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end
    elseif location(1) == N && location(2) == N
        mylimit5 = rand;

        if mylimit5 > 1/2
            location(2) = location(2) - 1; % South
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit5 < 1/2
            location(1) = location(1) - 1; % West
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end        
    elseif location(1) == N && location(2) == -N
        mylimit6 = rand;

        if mylimit6 > 1/2
            location(2) = location(2) + 1; % North
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit6 < 1/2
            location(1) = location(1) - 1; % West
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end  
    elseif location(1) == -N && location(2) == N
        mylimit7 = rand;

        if mylimit7 > 1/2
            location(2) = location(2) - 1; % South
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit7 < 1/2
            location(1) = location(1) + 1; % East
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end 
    elseif location(1) == -N && location(2) == -N
        mylimit8 = rand;

        if mylimit8 > 1/2
            location(2) = location(2) + 1; % North
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        elseif mylimit8 < 1/2
            location(1) = location(1) + 1; % East
            if n == 0
                n = n + 1;
            elseif n > 0
                step_number = step_number + 1;
            end
        end  
    
%%-----------------------------------------------------------------------------
    elseif abs(location(1)) < N && abs(location(2)) < N

        if abs(location(1)) < 3 && location(2) > 3 && location(2) <= 6
            if rand < .15
                location(2) = location(2) - 1; % South
                if n == 0
                    n = n + 1;
                elseif n > 0
                    step_number = step_number + 1;
                end
            else
                myr1 = rand;
                if myr1 < 1/3
                    location(2) = location(2) + 1; % North
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr1 > 1/3 && myr1 < 2/3
                    location(1) = location(1) + 1; % East
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr1 < 1 && myr1 > 2/3
                    location(1) = location(1) - 1; % West
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
                
            end
    
    
    
        elseif abs(location(2)) < 3 && location(1) > 3 && location(1) <= 6
            if rand < .15
                location(1) = location(1) - 1; % West
                if n == 0
                    n = n + 1;
                elseif n > 0
                    step_number = step_number + 1;
                end
            else
                myr2 = rand;
                if myr2 < 1/3
                    location(2) = location(2) + 1; % North
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr2 > 1/3 && myr2 < 2/3
                    location(1) = location(1) + 1; % East
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr2 < 1 && myr2 > 2/3
                    location(2) = location(2) - 1; % South
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
            end
        
        
        elseif location(2) < -3 && abs(location(1)) < 3 && location(2) >= -6
            if rand < .15
                location(2) = location(2) + 1; % North
                if n == 0
                    n = n + 1;
                elseif n > 0
                    step_number = step_number + 1;
                end
            else
                myr3 = rand;
                if myr3 < 1/3
                    location(1) = location(1) - 1; % West
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr3 > 1/3 && myr3 < 2/3
                    location(1) = location(1) + 1; % East
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr3 < 1 && myr3 > 2/3
                    location(2) = location(2) - 1; % South
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
            end
        
        
        elseif abs(location(2)) < 3 && location(1) >= -6 && location(1) < -3
            if rand < .15 
                location(1) = location(1) + 1; % East
                step_number = step_number + 1;
            else
                myr4 = rand;
                if myr4 < 1/3
                    location(2) = location(2) + 1; % North
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr4 > 1/3 && myr4 < 2/3
                    location(1) = location(1) - 1; % West
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                elseif myr4 < 1 && myr4 > 2/3
                    location(2) = location(2) - 1; % South
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
            end
        
        
        elseif abs(location(1)) == 3 && abs(location(2)) == 3
            if rand < .5 
                if rand < .5
                    location(1) = location(1) + 1; % East
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                else
                    location(1) = location(1) - 1; % West
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
            else
                if rand < .5
                    location(2) = location(2) + 1; % North
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                else
                    location(2) = location(2) - 1; % South
                    if n == 0
                        n = n + 1;
                    elseif n > 0
                        step_number = step_number + 1;
                    end
                end
            end
        else
            if rand < .5
                if rand < .5
                    location(1) = location(1) + 1; % East

                    if n > 0
                        step_number = step_number + 1;
                    end
                else
                    location(1) = location(1) - 1; % West

                    if n > 0
                        step_number = step_number + 1;
                    end       
                end
            else
                if rand < .5
                    location(2) = location(2) + 1; % North
                    if n > 0
                        step_number = step_number + 1;
                    end
                else
                    location(2) = location(2) - 1; % South

                    if n > 0
                        step_number = step_number + 1;
                    end
                end
            end
        
        
        end
   
    


        if location(1) == 0 && location(2) == 0 && n >0
            break
        end 
    end

end
fprintf("The first visit to the cell (0,0) -after the ball is in at least one of the regions- is reached in step %f",step_number)
