%ENES GÖK 2444628
clear
clc
ware_x = input("Enter the x coordinate of warehouse: ");
ware_y = input("Enter the y coordinate of warehouse: ");
warehouse = [ware_x,ware_y];
stop = input("Stoppng criteria: ");

weight = [8,4,10,7,6,5,1,7,3,11,9,5,4,12,6,9,8];
price = [0.02,0.05,0.02,0.03,0.03,0.03,0.05,0.03,0.04,0.05,0.04,0.02,0.03,0.05,0.06,0.02,0.03];
x_coordinates = [32,27,28,37,41,36,30,41,35,36,30,17,27,38,22,13,24];
y_coordinates = [39,38,41,37,39,41,36,37,25,29,43,35,42,18,51,26,38];
old = 0;
next_x = 0;
next_y = 0;
iterationx = [0];
iterationy = [0];
while true    

    cost = 0;
    sum_distance=0;
    for i = 1:17
        sum_distance = sum_distance + (x_coordinates(i)-warehouse(1))^2 + (y_coordinates(i)-warehouse(2))^2;
        distance = sqrt(sum_distance);
        sum_cost = weight(i)*price(i)*distance;
        cost = cost + sum_cost;
    
        sum_x = ((weight(i)*price(i)*x_coordinates(i))/distance)/(weight(i)*price(i)/distance);
        next_x = next_x + sum_x;

        sum_y = ((weight(i)*price(i)*y_coordinates(i))/distance)/(weight(i)*price(i)/distance);
        next_y = next_y + sum_y;
    end
    iterationx(length(iterationx)) = next_x;
    iterationy(length(iterationy)) = next_y;
    warehouse(1) = next_x;
    warehouse(2) = next_y;
    next_x = 0;
    next_y = 0;
    if abs(old - cost) == stop
        break
    end
    old = cost;
    
end
plot(iterationx,iterationy,"p",'MarkerEdgeColor',"r",'MarkerSize',14)