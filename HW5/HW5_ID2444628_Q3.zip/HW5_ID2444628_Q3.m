%ENES GÖK 2444628
clear
clc
N = input("Enter the grid size (it should be an odd integer): ");
target_x = input("Enter the x-coordinate of the target cell: ");
target_y = input("Enter the y-coordinate of the target cell: ");
target_step = input("Enter the specific step number: ");
coordinate = [0,0];
step_number = 0;
x_trajectory = 0;
plot_x = 1;
y_trajectory = 0;
n=1;
while true
    
    step = randi([1,4]);
    if step == 1 && coordinate(2) ~= N 
        %UP
        coordinate(2) =coordinate(2)+1;
        step_number = step_number + 1;

    elseif step == 2 && coordinate(2) ~= -N 
        %DOWN
        coordinate(2) =coordinate(2)-1;
        step_number = step_number + 1;

    elseif step == 3 && coordinate(1) ~= N 
        %RIGHT
        coordinate(1) =coordinate(1)+1;
        step_number = step_number + 1;

    elseif step == 4 && coordinate(1) ~= -N 
        %LEFT
        coordinate(1) =coordinate(1)-1;
        step_number = step_number + 1;
    end
    if target_step <= step_number
        if length(x_trajectory) <= target_step 
            n=n+1;
            x_trajectory(length(x_trajectory)+1) = coordinate(1);
            plot_x(length(plot_x)+1) = n;
       
        end
    elseif target_step > step_number
        n=n+1;
        x_trajectory(length(x_trajectory)+1) = coordinate(1);
        plot_x(length(plot_x)+1) = n;
    end
    if target_step <= step_number
        if length(y_trajectory) <= target_step
            y_trajectory(length(y_trajectory)+1) = coordinate(2);
        end
    elseif target_step > step_number
        y_trajectory(length(y_trajectory)+1) = coordinate(2);
    end
    if coordinate(1) == target_x && coordinate(2) == target_y
        fprintf("First visit to cell (%f,%f) reached in step %.0f.",coordinate(1),coordinate(2),step_number)
        break
    end

end
subplot(2,1,1)
plot(plot_x,x_trajectory)
title("x-coordinate trajectory")
subplot(2,1,2)
plot(plot_x,y_trajectory)
title("y-coordinate trajectory")