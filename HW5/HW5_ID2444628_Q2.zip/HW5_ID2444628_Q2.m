%ENES GÖK 2444628
clear
clc
old_init_val = [0,0,0,0];
new_init_val = [0,0,0,0];
sum = 0;
error = 0;
a = 0;
iteration = 0;
variable = "x";
n=1;
while n < 4    
    while true
        new_init_val(1) = (12 - old_init_val(2) - old_init_val(3) - 2*old_init_val(4)) / 9 ;
        new_init_val(2) = (18 - 2*old_init_val(1) - 3*old_init_val(3) + old_init_val(4)) / 10; 
        new_init_val(3) = (1 - 3*old_init_val(1) - 4*old_init_val(2) - old_init_val(4))  / 11;
        new_init_val(4) = 7 - old_init_val(1) - 2*old_init_val(2) + old_init_val(3);
        for i = 1:4
            sum = sum + (new_init_val(i)-old_init_val(i))^2;
        end
        
        error = sqrt(sum);
        iteration = iteration + 1;
    
        if error < 10^-2 && a == 0
            fprintf("For error 10−2:\n")
            fprintf("When initial solution is %s: The result is (%f,%f,%f,%f) after %f iterations.\n",variable,new_init_val(1),new_init_val(2),new_init_val(3),new_init_val(4),iteration)
            a = a + 1;
        end
        if error < 10^-4 && a == 1
            fprintf("For error 10−4:\n")
            fprintf("When initial solution is %s: The result is (%f,%f,%f,%f) after %f iterations.\n",variable,new_init_val(1),new_init_val(2),new_init_val(3),new_init_val(4),iteration)
            a = a + 1;
        end
        if error < 10^-6 && a == 2
            fprintf("For error 10−6:\n")
            fprintf("When initial solution is %s: The result is (%f,%f,%f,%f) after %f iterations.\n",variable,new_init_val(1),old_init_val(2),new_init_val(3),new_init_val(4),iteration)
            a = 0;
            break
        end
        
        
        for i = 1:4
            old_init_val(i)=new_init_val(i);
        end
        sum = 0;
    end
    n = n + 1;
    if n == 2
        variable = "y";
        old_init_val = [10,10,10,10];
        iteration = 0;
        sum = 0;
        a = 0;
        error = 0;
    
    elseif n == 3
        variable = "z";
        old_init_val = [1,1,1,1];
        iteration = 0;
        sum = 0;
        a = 0;
        error = 0;
    end
end
