%ENES GÖK 2444628
clear
clc
N = input("Enter the grid size (it should be an odd integer): ");
my_area = zeros(N,N);
find_max = zeros(N,N);
the_point = [(N+1)/2,(N+1)/2];
my_area(the_point(1),the_point(2)) = 1;
find_max(the_point(1),the_point(2)) = 1;
target_row = input("Enter the x-coordinate of the cell: ");
target_col = input("Enter the y-coordinate of the cell: ");
step = 0;
a = 0;
while true
    if the_point(1) == N && the_point(2) == N
        if rand < 0.25
            the_point(1) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    elseif the_point(1) == 1 && the_point(2) == N
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end    
    elseif the_point(1) == 1 && the_point(2) == 1
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end 
    elseif the_point(1) == N && the_point(2) == 1
        if rand < 0.25
            the_point(1) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    elseif the_point(1) == N && the_point(2) ~= N && the_point(2) ~= 1
        if rand < 0.25
            the_point(1) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    elseif the_point(2) == N && the_point(1) ~= N && the_point(1) ~= 1
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    elseif the_point(2) == 1 && the_point(1) ~= N && the_point(1) ~= 1
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    elseif the_point(1) == 1 && the_point(2) ~= N && the_point(2) ~= 1
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = N;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    else
        if rand < 0.25
            the_point(1) = the_point(1) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.5
            the_point(2) = the_point(2) + 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        elseif rand < 0.75
            the_point(1) = the_point(1) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        else
            the_point(2) = the_point(2) - 1;
            my_area(the_point(1),the_point(2)) = 1;
            find_max(the_point(1),the_point(2)) = find_max(the_point(1),the_point(2)) + 1;
        end
    end
    step = step + 1;

    if the_point(1) == target_row && the_point(2) == target_col && a == 0
        fprintf(" First visit to cell (%f,%f) happened in time %f\n",target_row,target_col,step)
        a = a + 1;
    end
    if my_area == zeros(N,N)+1
        [x,y] = find(find_max == max(max(find_max)));
        for i = 1:length(x)
            fprintf("The most visited cell is (%f,%f)\n",x(i),y(i))
        end
        fprintf("Total number of visits is %f",step)
        break
    end
end
