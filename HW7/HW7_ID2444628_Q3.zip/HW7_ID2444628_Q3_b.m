%ENES GÖK 2444628
clear
clc

average = [];
target_row = input("Enter the x-coordinate of the cell: ");
target_col = input("Enter the y-coordinate of the cell: ");

a = 0;
for N = 5:2:25

    the_point = [(N+1)/2,(N+1)/2];
    step = 0;
    while step < 500
        if the_point(1) == N && the_point(2) == N
            if rand < 0.25
                the_point(1) = 1;

            elseif rand < 0.5
                the_point(2) = 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = the_point(2) - 1;

            end
        elseif the_point(1) == 1 && the_point(2) == N
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = 1;

            elseif rand < 0.75
                the_point(1) = N;

            else
                the_point(2) = the_point(2) - 1;

            end    
        elseif the_point(1) == 1 && the_point(2) == 1
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = N;

            else
                the_point(2) = N;

            end 
        elseif the_point(1) == N && the_point(2) == 1
            if rand < 0.25
                the_point(1) = 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = N;

            end
        elseif the_point(1) == N && the_point(2) ~= N && the_point(2) ~= 1
            if rand < 0.25
                the_point(1) = 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = the_point(2) - 1;

            end
        elseif the_point(2) == N && the_point(1) ~= N && the_point(1) ~= 1
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = the_point(2) - 1;

            end
        elseif the_point(2) == 1 && the_point(1) ~= N && the_point(1) ~= 1
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = N;

            end
        elseif the_point(1) == 1 && the_point(2) ~= N && the_point(2) ~= 1
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = N;

            else
                the_point(2) = the_point(2) - 1;

            end
        else
            if rand < 0.25
                the_point(1) = the_point(1) + 1;

            elseif rand < 0.5
                the_point(2) = the_point(2) + 1;

            elseif rand < 0.75
                the_point(1) = the_point(1) - 1;

            else
                the_point(2) = the_point(2) - 1;

            end
        end
        step = step + 1;
    
        if the_point(1) == target_row && the_point(2) == target_col 
            a = a + 1;
        end
    end
    average(end+1) = a;
    a= 0;
end
disp(sum(average)/length(average))
