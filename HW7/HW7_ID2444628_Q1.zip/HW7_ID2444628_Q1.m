%ENES GÖK 2444628
clear
clc
load newCust.mat
num = readmatrix("Prevcust.xlsx");
sum = 0;
find_nearest = [];
for i=2:height(num)
    for j=1:width(num)-1
        sum = sum + (newCust(1,j)-num(i,j))^2;
        euclidean = sqrt(sum);
        find_nearest(end+1) = euclidean;
        if euclidean == min(find_nearest)
            a = num(i,11);
            disp(i)
        end
    end
    sum = 0;
end
if a == 1
    fprintf("The status of the new customer is A.")
elseif a == 0
    fprintf("The status of the new customer is NA.")
end