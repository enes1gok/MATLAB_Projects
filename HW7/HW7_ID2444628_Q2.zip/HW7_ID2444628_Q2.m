%ENES GÖK 2444628
clear
clc
sum = 0;
my_city = zeros(100,100);
drivers_row = [2,7,90];
drivers_col = [50,9,45];

my_city(drivers_row(1),drivers_col(1)) = 1;
my_city(drivers_row(2),drivers_col(2)) = 1;
my_city(drivers_row(3),drivers_col(3)) = 1;

customer_row = ceil(100*rand);
customer_col= ceil(100*rand);
my_city(customer_row,customer_col) = 2;

find_nearest = [];

for i=1:3
    sum = sum + (abs(drivers_row(i)-customer_row))^2;
    sum = sum + (abs(drivers_col(i)-customer_col))^2;
    euclidean = sqrt(sum);
    find_nearest(end+1) = euclidean;
    sum=0;
end

manhattan3 = abs(drivers_row(3)-customer_row) + abs(drivers_col(3)-customer_col);
manhattan2 = abs(drivers_row(2)-customer_row) + abs(drivers_col(2)-customer_col);
manhattan1 = abs(drivers_row(1)-customer_row) + abs(drivers_col(1)-customer_col);   
if mod(min(find_nearest),find_nearest) > 1
    if find_nearest(2) == find_nearest(3)
        if manhattan2 < manhattan3
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",2,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(2))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan2)

        elseif manhattan3 < manhattan2 
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",3,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(3))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan3)
                
        end
            
    elseif find_nearest(2) == find_nearest(1) 
        if manhattan2 < manhattan1
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",2,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(2))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan2)

        elseif manhattan1 < manhattan2 
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",1,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(1))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan1)  
                
        end
    elseif find_nearest(3) == find_nearest(1)         
        if manhattan3 < manhattan1
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",3,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(3))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan3)

        elseif manhattan1 < manhattan3 
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",1,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(1))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan1)  
        end
            
     end
else

        if min(find_nearest) == find_nearest(1)
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",1,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(1))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan1) 
        elseif min(find_nearest) == find_nearest(2)
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",2,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(2))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan2)
        elseif min(find_nearest) == find_nearest(3)
            fprintf("Direct driver %f to the customer with location (%f,%f).\n",3,customer_row,customer_col)
            fprintf("The minimum distance to reach the customer is %f kms.\n",find_nearest(3))
            fprintf("The maximum distance to reach the customer is %f kms.\n",manhattan3)
        end

end
