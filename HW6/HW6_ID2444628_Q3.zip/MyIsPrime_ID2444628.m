function result = MyIsPrime_ID2444628(x)
    n=0;
    for i = 2:x
        while true
            if rem(x,i) == 0
                n=n+1;
                x = x/i;
                %i is a prime multiplier
            else
                break
            end
        end
    end
    if n == 1
        result = "true";
    else
        result = "false";

    end
