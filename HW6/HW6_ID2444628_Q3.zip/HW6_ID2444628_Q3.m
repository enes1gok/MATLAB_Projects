%ENES GÖK 2444628
clear
clc
x = input("What is the number: ");
PrintPrimeMult_ID2444628(x,MyIsPrime_ID2444628(x))
