function multiplier = PrintPrimeMult_ID2444628(x,p) 
    fprintf("Prime multipliers of %f:\n",x)
    multiplier = x;
    if p == "false"
        n=0;
        for i = 2:x
            while true
                if rem(x,i) == 0
                    
                    x = x/i;
                    
                    %i is a prime multiplier
                    if n == 0
                        
                        disp(i)
                    end
                    n=n+1;
                else
                    n=0;
                    break
                end
            end
        end
    end