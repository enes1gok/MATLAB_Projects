function root_est = FindRoot_ID2444628(a,b,c,x1,x2,stop)
    [y,a,b,c,x1,x2] = CheckRoot_ID2444628;
    if y==1
        i=0;
        while true
            r1 = ((a*x2^2+b*x2+c)-(a*x1^2+b*x1+c))/(x2-x1);
            r2 = (a*x2^2+b*x2+c)-r1*x2;
            firstxmid = r2/r1;
            result = a*firstxmid^2+b*firstxmid+c;
            if result < 0 && (a*x1^2+b*x1+c)>0
                x2=result;
            elseif result < 0 && (a*x2^2+b*x2+c)<0
                x1=result;
            end
            r1 = ((a*x2^2+b*x2+c)-(a*x1^2+b*x1+c))/(x2-x1);
            r2 = (a*x2^2+b*x2+c)-r1*x2;
            xmid = r2/r1;
            result = a*xmid^2+b*xmid+c;
    
            error = abs(firstxmid-xmid);
            if error<=stop
                break
            end
            firstxmid=xmid;
            i=i+1;
        end
        root_est=xmid;
        
  
    end
    