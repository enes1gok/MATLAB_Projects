function a = CheckRoot_ID2444628(x1,x2)
for i = x1:x2
    if r1 > x1 && r1 < x2
        a = 1;
        %there is one root
    elseif r2 > x1 && r2 < x2
        %there is one root
        a = 1;
    else
        %no root
        a = 0;
    end
    
end
((xpos-xneg))/(f(xpos)-f(xneg)) = (xpos - xmid)/(f(xpos)-f(xmid));
((xpos-xneg))/(f(xpos)-f(xneg)) = (xmid-xneg)/(f(xmid)-f(xneg));
f(xmid) = 0;