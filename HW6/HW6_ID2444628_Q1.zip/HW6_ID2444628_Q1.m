%ENES GÖK 2444628
clear
clc
x1 = input("Specify the first end point of the interval: ");
x2 = input("Specify the second end point of the interval: ");
unknown=CheckRoot_ID2444628(x1,x2);
FindRoot_ID2444628
if unknown == 1
    fprintf("The root of the function for the given interval is approximated as %f",FindRoot_ID2444628)
else
    fprintf("There is no root or more than one root in the given interval.")
end


