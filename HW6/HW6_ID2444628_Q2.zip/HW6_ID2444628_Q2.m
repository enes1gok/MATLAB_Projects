%ENES GÖK 2444628
clear
clc
x = [ ];
y = [ ];
for i = 1:0.01:7
    x(end+1) = i;
    y(end+1) = 20*sin(i+3)*cos((i^2)/2);
end
plot(x,y)
a,b = Number_of_Local_Min_ID2444628;
for j = 1:length(b)  
    for i=b(j)-10^-2:10^-6:b(j)+10^-2
        Find_Local_Min_ID2444628(i,i+10^-2)
    end
end
global_min = min(b);
f1 = figure;
plot(x,y,MarkerSize=14,Color="r",Marker="*",x,global_min,Marker="pentagram")