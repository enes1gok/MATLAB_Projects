function [num_loc_mins,list_of_local_mins] = Number_of_Local_Min_ID2444628(x,y)
    num_loc_mins = 0;
    list_of_local_mins = [ ];
    n=1;
    while n <= 6.98    
        for i = 1:599
            first = y(i);
            second = y(i+1);
            third = y(i+2);
            if second < first && second < third
                num_loc_mins = num_loc_mins + 1;
                list_of_local_mins(end+1) = second;
            end
        end
        if y(-1)<y(-2)
             num_loc_mins = num_loc_mins + 1;
             list_of_local_mins(end+1) = [y(-1)];
        end
        if y(1)<y(2)
             num_loc_mins = num_loc_mins + 1;
             list_of_local_mins(end+1) = [y(1)];
        end

        n = n+0.01;
    end
end