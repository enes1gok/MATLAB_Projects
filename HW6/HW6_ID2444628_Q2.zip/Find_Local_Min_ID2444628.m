function [xcoor,ycoor] = Find_Local_Min_ID2444628(a,b)
    for i=a:10^-6:b-(10^-6*2)
        first = 20*sin(i+3)*cos((i^2)/2);
        second = 20*sin(((i+10^-6)+10^-6)+3)*cos(((i+10^-6)^2)/2);
        third = 20*sin((i+10^-6*2)+3)*cos(((i+10^-6*2)^2)/2);
        if second < first && second < third
            xcoor = i+10^-6;
            ycoor = second;
        end
    end
end